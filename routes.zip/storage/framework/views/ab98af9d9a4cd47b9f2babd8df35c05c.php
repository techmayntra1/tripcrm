<?php $__env->startSection('title', 'Tasks'); ?>
<?php $__env->startSection('content'); ?>
<div class="app-page-title">
    <div class="page-title-wrapper">
        <div class="page-title-heading">
            <div class="page-title-icon">
                <i class="bi bi-list-task icon-gradient bg-sunny-morning"></i>
            </div>
            <div>
                Tasks
            </div>
        </div>
        <div class="page-title-actions">
            <?php if(auth()->user()->hasPermission('tasks', 'create')): ?>
            <button type="button" class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#addTaskModal" title="Add Task">
                <i class="bi bi-plus-lg"></i>
            </button>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php if(session('success')): ?>
<div class="alert alert-success alert-dismissible fade show" role="alert">
    <?php echo e(session('success')); ?>

    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
<?php endif; ?>
<?php if(session('error')): ?>
<div class="alert alert-danger alert-dismissible fade show" role="alert">
    <i class="bi bi-exclamation-triangle me-2"></i><?php echo e(session('error')); ?>

    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
<?php endif; ?>
<?php if($errors->any()): ?>
<div class="alert alert-danger alert-dismissible fade show" role="alert">
    <i class="bi bi-exclamation-triangle me-2"></i>
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php echo e($error); ?><br>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
<?php endif; ?>
<div class="row">
    <div class="col-12">
        <div class="main-card mb-3 card">
            <div class="card-header has-tabs d-flex justify-content-between align-items-center">
                <ul class="nav lead-tabs" role="tablist">
                    <li class="nav-item">
                        <a class="nav-link <?php echo e(request('tab') != 'deleted' ? 'active' : ''); ?>" href="<?php echo e(route('admin.tasks.index')); ?>">
                            <i class="bi bi-list-task me-1"></i> Active (<?php echo e($allCount); ?>)
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo e(request('tab') == 'deleted' ? 'active' : ''); ?>" href="<?php echo e(route('admin.tasks.index', ['tab' => 'deleted'])); ?>">
                            <i class="bi bi-archive me-1"></i> Deleted (<?php echo e($deletedCount); ?>)
                        </a>
                    </li>
                </ul>
                <div class="d-flex align-items-center gap-2">
                    <?php if(request('tab') != 'deleted'): ?>
                    <form method="GET" action="<?php echo e(route('admin.tasks.index')); ?>" id="filterForm">
                        <?php if(request('search')): ?>
                        <input type="hidden" name="search" value="<?php echo e(request('search')); ?>">
                        <?php endif; ?>
                        <select name="tab" class="form-select form-select-sm" style="width: auto;" onchange="document.getElementById('filterForm').submit()">
                            <option value="" <?php echo e(!request('tab') ? 'selected' : ''); ?>>All</option>
                            <option value="today" <?php echo e(request('tab') == 'today' ? 'selected' : ''); ?>>Today (<?php echo e($todayCount ?? 0); ?>)</option>
                            <option value="upcoming" <?php echo e(request('tab') == 'upcoming' ? 'selected' : ''); ?>>Upcoming (<?php echo e($upcomingCount ?? 0); ?>)</option>
                            <option value="past" <?php echo e(request('tab') == 'past' ? 'selected' : ''); ?>>Overdue (<?php echo e($pastCount ?? 0); ?>)</option>
                            <option value="in_progress" <?php echo e(request('tab') == 'in_progress' ? 'selected' : ''); ?>>In Progress (<?php echo e($inProgressCount ?? 0); ?>)</option>
                            <option value="completed" <?php echo e(request('tab') == 'completed' ? 'selected' : ''); ?>>Completed (<?php echo e($completedCount); ?>)</option>
                        </select>
                    </form>
                    <?php endif; ?>
                    <form method="GET" action="<?php echo e(route('admin.tasks.index')); ?>" class="d-flex align-items-center gap-2">
                        <?php if(request('tab')): ?>
                        <input type="hidden" name="tab" value="<?php echo e(request('tab')); ?>">
                        <?php endif; ?>
                        <div class="input-group input-group-sm" style="width: 250px;">
                            <input type="text" name="search" class="form-control" placeholder="Search tasks" value="<?php echo e(request('search')); ?>">
                            <button class="btn btn-outline-secondary" type="submit">
                                <i class="bi bi-search"></i>
                            </button>
                        </div>
                        <?php if(request('search')): ?>
                        <a href="<?php echo e(route('admin.tasks.index', request('tab') ? ['tab' => request('tab')] : [])); ?>" class="btn btn-sm btn-danger" title="Clear">
                            <i class="bi bi-x-lg"></i>
                        </a>
                        <?php endif; ?>
                    </form>
                </div>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                <table class="table table-hover mb-0">
                    <thead>
                        <tr>
                            <th style="white-space: nowrap">SR</th>
                            <th>Title</th>
                            <th>Trip</th>
                            <th>Assigned To</th>
                            <th style="white-space: nowrap">Start Date</th>
                            <th style="white-space: nowrap">Due Date</th>
                            <th>Location</th>
                            <th style="white-space: nowrap">Status</th>
                            <th style="white-space: nowrap">Actions</th>
                        </tr>
                    </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td>
                                    <?php if($task->trashed()): ?>
                                    <a href="<?php echo e(route('admin.tasks.trashed.show', $task->id)); ?>" class="name-truncate" title="<?php echo e($task->title); ?>"><strong><?php echo e($task->title); ?></strong></a>
                                    <?php else: ?>
                                    <a href="<?php echo e(route('admin.tasks.show', $task)); ?>" class="name-truncate" title="<?php echo e($task->title); ?>"><strong><?php echo e($task->title); ?></strong></a>
                                    <?php endif; ?>
                                    <?php if($task->description): ?>
                                    <br><small class="text-muted"><?php echo e(Str::limit($task->description, 50)); ?></small>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if($task->trip): ?>
                                        <a href="<?php echo e(route('admin.trips.show', $task->trip)); ?>" class="name-truncate"><?php echo e($task->trip->name); ?></a>
                                    <?php else: ?>
                                        <span class="text-muted">-</span>
                                    <?php endif; ?>
                                </td>
                                <td class="text-center">
                                    <span class="name-truncate"><?php echo e($task->assignee_name); ?></span>
                                    <br><small class="text-muted"><?php echo e(ucfirst($task->assignee_type)); ?></small>
                                </td>
                                <td>
                                    <strong><?php echo e($task->start_at->format('d-m-Y')); ?></strong>
                                    <br><small class="text-muted"><?php echo e($task->start_at->format('h:i A')); ?></small>
                                </td>
                                <td>
                                    <?php if($task->due_at): ?>
                                        <strong><?php echo e($task->due_at->format('d-m-Y')); ?></strong>
                                        <br><small class="text-muted"><?php echo e($task->due_at->format('h:i A')); ?></small>
                                    <?php else: ?>
                                        <span class="text-muted">-</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if($task->location): ?>
                                        <span class="name-truncate" title="<?php echo e($task->location); ?>"><?php echo e(Str::limit($task->location, 30)); ?></span>
                                    <?php else: ?>
                                        <span class="text-muted">-</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <span class="badge bg-<?php echo e($task->status_color); ?>">
                                        <?php echo e($task->status_name); ?>

                                    </span>
                                </td>
                                <td>
                                    <div class="gap-1">
                                        <?php if($task->trashed()): ?>
                                            <?php if(auth()->user()->hasPermission('tasks', 'edit')): ?>
                                            <form action="<?php echo e(route('admin.tasks.reactivate', $task->id)); ?>" method="POST" class="d-inline">
                                                <?php echo csrf_field(); ?>
                                                <button type="submit" class="btn btn-sm btn-outline-success" title="Restore">
                                                    <i class="bi bi-arrow-counterclockwise"></i>
                                                </button>
                                            </form>
                                            <?php endif; ?>
                                        <?php elseif($task->status_name === 'Completed'): ?>
                                            <?php if(auth()->user()->hasPermission('tasks', 'edit')): ?>
                                            <form action="<?php echo e(route('admin.tasks.deactivate', $task)); ?>" method="POST" class="d-inline" onsubmit="return confirm('Delete this task?')">
                                                <?php echo csrf_field(); ?>
                                                <button type="submit" class="btn btn-sm btn-outline-danger" title="Delete">
                                                    <i class="bi bi-archive"></i>
                                                </button>
                                            </form>
                                            <?php endif; ?>
                                        <?php else: ?>
                                            <a href="<?php echo e(route('admin.tasks.show', $task)); ?>" class="btn btn-sm btn-outline-info" title="View">
                                                <i class="bi bi-eye"></i>
                                            </a>
                                            <?php if(auth()->user()->hasPermission('tasks', 'edit')): ?>
                                            <button type="button" class="btn btn-sm btn-outline-primary" title="Edit" data-bs-toggle="modal" data-bs-target="#editTaskModal<?php echo e($task->id); ?>">
                                                <i class="bi bi-pencil"></i>
                                            </button>
                                            <button type="button" class="btn btn-sm btn-outline-warning" title="Update Status" data-bs-toggle="modal" data-bs-target="#statusTaskModal<?php echo e($task->id); ?>">
                                                <i class="bi bi-arrow-repeat"></i>
                                            </button>
                                            <form action="<?php echo e(route('admin.tasks.deactivate', $task)); ?>" method="POST" class="d-inline" onsubmit="return confirm('Delete this task?')">
                                                <?php echo csrf_field(); ?>
                                                <button type="submit" class="btn btn-sm btn-outline-danger" title="Delete">
                                                    <i class="bi bi-archive"></i>
                                                </button>
                                            </form>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="9" class="text-center py-4 text-muted">
                                    <i class="bi bi-list-task fs-3 d-block mb-2"></i>
                                    No tasks found.
                                </td>
                            </tr>
                            <?php endif; ?>
                    </tbody>
                </table>
                </div>
            </div>
            <div class="card-footer">
                <?php echo $__env->make('partials.pagination', ['paginator' => $tasks], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('modals'); ?>
<?php if(auth()->user()->hasPermission('tasks', 'create')): ?>

<div class="modal fade" id="addTaskModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header bg-warning">
                <h5 class="modal-title"><i class="bi bi-plus-circle me-2"></i>Add Task</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form action="<?php echo e(route('admin.tasks.store')); ?>" method="POST" id="addTaskForm">
                <?php echo csrf_field(); ?>
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label">Task Title <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" name="title" id="addTaskTitle" value="<?php echo e(old('title')); ?>" maxlength="100">
                        <div class="invalid-feedback">Please enter task title</div>
                    </div>
                    <div class="row">
                        <div class="col-md-12 mb-3">
                            <label class="form-label">Trip</label>
                            <select class="form-select" name="trip_id" id="addTripId">
                                <option value="">Select Trip</option>
                                <?php $__currentLoopData = $trips; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trip): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($trip->id); ?>" data-address="<?php echo e($trip->site_address); ?>" <?php echo e(old('trip_id') == $trip->id ? 'selected' : ''); ?>><?php echo e(Str::limit($trip->name, 40)); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Start Date & Time <span class="text-danger">*</span></label>
                            <input type="datetime-local" class="form-control" name="start_at" id="addStartAt" value="<?php echo e(old('start_at', date('Y-m-d') . 'T10:00')); ?>">
                            <div class="invalid-feedback">Please select start date and time</div>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Due Date & Time</label>
                            <input type="datetime-local" class="form-control" name="due_at" id="addDueAt" value="<?php echo e(old('due_at')); ?>" min="<?php echo e(old('start_at', date('Y-m-d') . 'T10:00')); ?>">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-4 mb-3">
                            <label class="form-label">Assign To <span class="text-danger">*</span></label>
                            <select class="form-select" name="assignee_type" id="addAssigneeType">
                                <option value="">Select Type</option>
                                <option value="staff" <?php echo e(old('assignee_type') == 'staff' ? 'selected' : ''); ?>>Staff</option>
                                <option value="vendor" <?php echo e(old('assignee_type') == 'vendor' ? 'selected' : ''); ?>>Vendor</option>
                            </select>
                            <div class="invalid-feedback">Please select assignee type</div>
                        </div>
                        <div class="col-md-8 mb-3" id="addStaffSection" style="<?php echo e(old('assignee_type') == 'staff' ? '' : 'display: none;'); ?>">
                            <label class="form-label">Select Staff <span class="text-danger">*</span></label>
                            <select class="form-select" name="staff_id" id="addStaffId">
                                <option value="">Select Staff</option>
                                <?php $__currentLoopData = $staffMembers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $staff): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($staff->id); ?>" <?php echo e(old('staff_id') == $staff->id ? 'selected' : ''); ?>><?php echo e($staff->name); ?> (<?php echo e($staff->role_display); ?>)</option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <div class="invalid-feedback">Please select a staff member</div>
                        </div>
                        <div class="col-md-8 mb-3" id="addVendorSection" style="<?php echo e(old('assignee_type') == 'vendor' ? '' : 'display: none;'); ?>">
                            <label class="form-label">Select Vendor <span class="text-danger">*</span></label>
                            <select class="form-select" name="vendor_id" id="addVendorId">
                                <option value="">Select Vendor</option>
                                <?php $__currentLoopData = $vendors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vendor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($vendor->id); ?>" <?php echo e(old('vendor_id') == $vendor->id ? 'selected' : ''); ?>><?php echo e($vendor->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <div class="invalid-feedback">Please select a vendor</div>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Location</label>
                        <input type="text" class="form-control" name="location" id="addLocation" value="<?php echo e(old('location')); ?>" maxlength="255" placeholder="Type to search trip addresses" list="tripAddressList">
                        <datalist id="tripAddressList">
                            <?php $__currentLoopData = $trips; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trip): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($trip->site_address): ?>
                                <option value="<?php echo e($trip->site_address); ?>"><?php echo e($trip->name); ?></option>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </datalist>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Description</label>
                        <textarea class="form-control" name="description" rows="2" maxlength="200"><?php echo e(old('description')); ?></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-warning">
                        <i class="bi bi-check-lg me-1"></i> Save Task
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php endif; ?>

<?php if(auth()->user()->hasPermission('tasks', 'edit')): ?>
<?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php if(!$task->trashed() && $task->status_name !== 'Completed'): ?>

<div class="modal fade" id="editTaskModal<?php echo e($task->id); ?>" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><i class="bi bi-pencil me-2"></i>Edit Task</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form action="<?php echo e(route('admin.tasks.update', $task)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label">Task Title <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" name="title" value="<?php echo e($task->title); ?>" maxlength="100">
                    </div>
                    <div class="row">
                        <div class="col-md-12 mb-3">
                            <label class="form-label">Trip</label>
                            <select class="form-select edit-trip-select" name="trip_id" data-task-id="<?php echo e($task->id); ?>">
                                <option value="">No Trip</option>
                                <?php $__currentLoopData = $trips; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trip): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($trip->id); ?>" data-address="<?php echo e($trip->site_address); ?>" <?php echo e($task->trip_id == $trip->id ? 'selected' : ''); ?>><?php echo e(Str::limit($trip->name, 40)); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Start Date & Time <span class="text-danger">*</span></label>
                            <input type="datetime-local" class="form-control task-start-at" name="start_at" value="<?php echo e($task->start_at->format('Y-m-d\TH:i')); ?>">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Due Date & Time</label>
                            <input type="datetime-local" class="form-control task-due-at" name="due_at" value="<?php echo e($task->due_at ? $task->due_at->format('Y-m-d\TH:i') : ''); ?>" min="<?php echo e($task->start_at->format('Y-m-d\TH:i')); ?>">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-4 mb-3">
                            <label class="form-label">Assign To <span class="text-danger">*</span></label>
                            <select class="form-select edit-assignee-type" data-task-id="<?php echo e($task->id); ?>" name="assignee_type">
                                <option value="">Select Type</option>
                                <option value="staff" <?php echo e($task->assignee_type == 'staff' ? 'selected' : ''); ?>>Staff</option>
                                <option value="vendor" <?php echo e($task->assignee_type == 'vendor' ? 'selected' : ''); ?>>Vendor</option>
                            </select>
                        </div>
                        <div class="col-md-8 mb-3 edit-staff-section-<?php echo e($task->id); ?>" style="<?php echo e($task->assignee_type == 'staff' ? '' : 'display: none;'); ?>">
                            <label class="form-label">Select Staff <span class="text-danger">*</span></label>
                            <select class="form-select" name="staff_id">
                                <option value="">Select Staff</option>
                                <?php $__currentLoopData = $staffMembers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $staff): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($staff->id); ?>" <?php echo e(($task->assignee_type == 'staff' && $task->assignee_id == $staff->id) ? 'selected' : ''); ?>><?php echo e($staff->name); ?> (<?php echo e($staff->role_display); ?>)</option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="col-md-8 mb-3 edit-vendor-section-<?php echo e($task->id); ?>" style="<?php echo e($task->assignee_type == 'vendor' ? '' : 'display: none;'); ?>">
                            <label class="form-label">Select Vendor <span class="text-danger">*</span></label>
                            <select class="form-select" name="vendor_id">
                                <option value="">Select Vendor</option>
                                <?php $__currentLoopData = $vendors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vendor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($vendor->id); ?>" <?php echo e(($task->assignee_type == 'vendor' && $task->assignee_id == $vendor->id) ? 'selected' : ''); ?>><?php echo e($vendor->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Location</label>
                        <input type="text" class="form-control edit-location-<?php echo e($task->id); ?>" name="location" value="<?php echo e($task->location); ?>" maxlength="255" placeholder="Type to search trip addresses" list="tripAddressList">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Description</label>
                        <textarea class="form-control" name="description" rows="2" maxlength="200"><?php echo e($task->description); ?></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">
                        <i class="bi bi-check-lg me-1"></i> Update Task
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>


<div class="modal fade" id="statusTaskModal<?php echo e($task->id); ?>" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header bg-warning">
                <h5 class="modal-title"><i class="bi bi-arrow-repeat me-2"></i>Update Status</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form action="<?php echo e(route('admin.tasks.status', $task)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label">Task Details</label>
                        <div class="p-3 bg-light rounded">
                            <strong><?php echo e($task->title); ?></strong><br>
                            <small class="text-muted">Start: <?php echo e($task->start_at->format('d-m-Y h:i A')); ?></small>
                            <?php if($task->due_at): ?>
                            <br><small class="text-muted">Due: <?php echo e($task->due_at->format('d-m-Y')); ?></small>
                            <?php endif; ?>
                            <br><small>Assigned to: <?php echo e($task->assignee_name); ?> (<?php echo e(ucfirst($task->assignee_type)); ?>)</small>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Status <span class="text-danger">*</span></label>
                            <select class="form-select" name="status_id">
                                <?php $__currentLoopData = $taskStatuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($status->id); ?>" <?php echo e($task->status_id == $status->id ? 'selected' : ''); ?>><?php echo e($status->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Due Date & Time</label>
                            <input type="datetime-local" class="form-control" name="due_at" value="<?php echo e($task->due_at ? $task->due_at->format('Y-m-d\TH:i') : ''); ?>" min="<?php echo e($task->start_at->format('Y-m-d\TH:i')); ?>">
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-warning"><i class="bi bi-check-lg me-1"></i> Update Status</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('styles'); ?>
<style>
    .task-filter-select {
        background-color: #ffc107 !important;
        color: #000 !important;
        border: none !important;
        font-weight: 600;
        padding: 8px 35px 8px 15px;
        border-radius: 6px;
        cursor: pointer;
        min-width: 160px;
    }
    .task-filter-select:focus {
        box-shadow: 0 0 0 3px rgba(255, 193, 7, 0.4) !important;
    }
    .task-filter-select option {
        background-color: #fff;
        color: #333;
        padding: 10px;
    }
    .card-header .form-control {
        background-color: #fff !important;
        color: #333 !important;
    }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
document.addEventListener('DOMContentLoaded', function() {
    var addStartAt = document.getElementById('addStartAt');
    var addDueAt = document.getElementById('addDueAt');
    if (addStartAt && addDueAt) {
        addStartAt.addEventListener('change', function() {
            addDueAt.min = this.value;
            if (addDueAt.value && addDueAt.value < this.value) {
                addDueAt.value = this.value;
            }
        });
    }

    document.querySelectorAll('.task-start-at').forEach(function(startInput) {
        var form = startInput.closest('form');
        var dueInput = form.querySelector('.task-due-at');
        if (dueInput) {
            startInput.addEventListener('change', function() {
                dueInput.min = this.value;
                if (dueInput.value && dueInput.value < this.value) {
                    dueInput.value = this.value;
                }
            });
        }
    });

    var addAssigneeType = document.getElementById('addAssigneeType');
    if (addAssigneeType) {
        addAssigneeType.addEventListener('change', function() {
            document.getElementById('addStaffSection').style.display = 'none';
            document.getElementById('addVendorSection').style.display = 'none';
            this.classList.remove('is-invalid');

            if (this.value === 'staff') {
                document.getElementById('addStaffSection').style.display = 'block';
            } else if (this.value === 'vendor') {
                document.getElementById('addVendorSection').style.display = 'block';
            }
        });
    }

    var addTripId = document.getElementById('addTripId');
    if (addTripId) {
        addTripId.addEventListener('change', function() {
            var selected = this.options[this.selectedIndex];
            var locationField = document.getElementById('addLocation');
            if (this.value && selected.dataset.address) {
                locationField.value = selected.dataset.address;
            }
        });
    }

    document.querySelectorAll('.edit-assignee-type').forEach(function(select) {
        select.addEventListener('change', function() {
            var taskId = this.getAttribute('data-task-id');
            document.querySelector('.edit-staff-section-' + taskId).style.display = 'none';
            document.querySelector('.edit-vendor-section-' + taskId).style.display = 'none';
            this.classList.remove('is-invalid');

            if (this.value === 'staff') {
                document.querySelector('.edit-staff-section-' + taskId).style.display = 'block';
            } else if (this.value === 'vendor') {
                document.querySelector('.edit-vendor-section-' + taskId).style.display = 'block';
            }
        });
    });

    document.querySelectorAll('.edit-trip-select').forEach(function(select) {
        select.addEventListener('change', function() {
            var taskId = this.getAttribute('data-task-id');
            var selected = this.options[this.selectedIndex];
            var locationField = document.querySelector('.edit-location-' + taskId);

            if (this.value && selected.dataset.address) {
                locationField.value = selected.dataset.address;
            }
        });
    });
    
    var addTaskForm = document.getElementById('addTaskForm');
    if (addTaskForm) {
        addTaskForm.addEventListener('submit', function(e) {
            var isValid = true;
            var assigneeType = document.getElementById('addAssigneeType');
            var startAt = document.getElementById('addStartAt');
            var title = document.getElementById('addTaskTitle');

            assigneeType.classList.remove('is-invalid');
            document.getElementById('addStaffId').classList.remove('is-invalid');
            document.getElementById('addVendorId').classList.remove('is-invalid');
            if (title) title.classList.remove('is-invalid');
            if (startAt) startAt.classList.remove('is-invalid');

            if (!title.value.trim()) {
                title.classList.add('is-invalid');
                isValid = false;
            }

            if (!startAt.value) {
                startAt.classList.add('is-invalid');
                isValid = false;
            }

            if (!assigneeType.value) {
                assigneeType.classList.add('is-invalid');
                isValid = false;
            } else if (assigneeType.value === 'staff') {
                var staffSelect = document.getElementById('addStaffId');
                if (!staffSelect.value) {
                    staffSelect.classList.add('is-invalid');
                    isValid = false;
                }
            } else if (assigneeType.value === 'vendor') {
                var vendorSelect = document.getElementById('addVendorId');
                if (!vendorSelect.value) {
                    vendorSelect.classList.add('is-invalid');
                    isValid = false;
                }
            }

            if (!isValid) {
                e.preventDefault();
            }
        });
    }

    <?php if(($errors->any() || session('error')) && old('_token')): ?>
        var addModalEl = document.getElementById('addTaskModal');
        if (addModalEl) {
            var addModal = new bootstrap.Modal(addModalEl);
            addModal.show();
        }
    <?php endif; ?>
});
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Workspace\tripcrm\resources\views/admin/tasks/index.blade.php ENDPATH**/ ?>