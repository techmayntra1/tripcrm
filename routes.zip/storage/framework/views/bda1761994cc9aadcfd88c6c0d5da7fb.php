
<footer class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-6">
                &copy; <?php echo e(date('Y')); ?> <?php echo e(config('app.name')); ?>.
            </div>
            <div class="col-sm-6">
                <div class="text-sm-end d-none d-sm-block">
                    All rights reserved.
                </div>
            </div>
        </div>
    </div>
</footer>
<?php /**PATH D:\Workspace\tripcrm\resources\views/partials/footer.blade.php ENDPATH**/ ?>