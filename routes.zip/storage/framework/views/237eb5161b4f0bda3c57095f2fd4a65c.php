<?php $__env->startSection('title', 'Trips'); ?>
<?php $__env->startSection('content'); ?>
<div class="app-page-title">
    <div class="page-title-wrapper">
        <div class="page-title-heading">
            <div class="page-title-icon">
                <i class="bi bi-kanban icon-gradient bg-strong-bliss"></i>
            </div>
            <div>
                Trips
            </div>
        </div>
        <div class="page-title-actions">
            <?php if(request('customer_id')): ?>
                <a href="<?php echo e(route('admin.customers.index')); ?>" class="btn btn-outline-secondary">
                    <i class="bi bi-arrow-left me-1"></i> Back to Customers
                </a>
            <?php endif; ?>
            <?php if(auth()->user()->hasPermission('trips', 'create')): ?>
            <a href="<?php echo e(route('admin.trips.create')); ?>" class="btn btn-primary" title="Create Trip">
                <i class="bi bi-plus-lg"></i>
            </a>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php if(session('success')): ?>
<div class="alert alert-success alert-dismissible fade show" role="alert">
    <?php echo e(session('success')); ?>

    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
<?php endif; ?>
<?php if(session('error')): ?>
<div class="alert alert-danger alert-dismissible fade show" role="alert">
    <?php echo e(session('error')); ?>

    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
<?php endif; ?>
<div class="main-card mb-3 card">
    <div class="card-header has-tabs d-flex justify-content-between align-items-center">
        <ul class="nav lead-tabs" role="tablist">
            <li class="nav-item">
                <a class="nav-link <?php echo e(request('tab') != 'deleted' ? 'active' : ''); ?>" href="<?php echo e(route('admin.trips.index')); ?>">
                    <i class="bi bi-kanban me-1"></i> Active (<?php echo e($allCount); ?>)
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo e(request('tab') == 'deleted' ? 'active' : ''); ?>" href="<?php echo e(route('admin.trips.index', ['tab' => 'deleted'])); ?>">
                    <i class="bi bi-archive me-1"></i> Deleted (<?php echo e($deletedCount); ?>)
                </a>
            </li>
        </ul>
        <div class="d-flex align-items-center gap-2">
            <?php if(request('tab') != 'deleted'): ?>
            <form method="GET" action="<?php echo e(route('admin.trips.index')); ?>" id="filterForm">
                <?php if(request('search')): ?>
                <input type="hidden" name="search" value="<?php echo e(request('search')); ?>">
                <?php endif; ?>
                <select name="tab" class="form-select form-select-sm" style="width: auto;" onchange="document.getElementById('filterForm').submit()">
                    <option value="" <?php echo e(!request('tab') ? 'selected' : ''); ?>>All</option>
                    <option value="planning" <?php echo e(request('tab') == 'planning' ? 'selected' : ''); ?>>Planning (<?php echo e($planningCount); ?>)</option>
                    <option value="in_progress" <?php echo e(request('tab') == 'in_progress' ? 'selected' : ''); ?>>In Progress (<?php echo e($inProgressCount); ?>)</option>
                    <option value="on_hold" <?php echo e(request('tab') == 'on_hold' ? 'selected' : ''); ?>>On Hold (<?php echo e($onHoldCount); ?>)</option>
                    <option value="completed" <?php echo e(request('tab') == 'completed' ? 'selected' : ''); ?>>Completed (<?php echo e($completedCount); ?>)</option>
                </select>
            </form>
            <?php endif; ?>
            <form method="GET" action="<?php echo e(route('admin.trips.index')); ?>" class="d-flex align-items-center gap-2">
                <?php if(request('tab')): ?>
                <input type="hidden" name="tab" value="<?php echo e(request('tab')); ?>">
                <?php endif; ?>
                <div class="input-group input-group-sm" style="width: 250px;">
                    <input type="text" name="search" class="form-control" placeholder="Search trips" value="<?php echo e(request('search')); ?>">
                    <button class="btn btn-outline-secondary" type="submit">
                        <i class="bi bi-search"></i>
                    </button>
                </div>
                <?php if(request('search')): ?>
                <a href="<?php echo e(route('admin.trips.index', request('tab') ? ['tab' => request('tab')] : [])); ?>" class="btn btn-sm btn-danger" title="Clear Filters">
                    <i class="bi bi-x-lg"></i>
                </a>
                <?php endif; ?>
            </form>
        </div>
    </div>
    <div class="card-body">
        <table class="table table-hover mb-0">
            <thead>
                <tr>
                    <th >SR</th>
                    <th>Trip</th>
                    <th>Client</th>
                    <th>Budget</th>
                    <th>Add On</th>
                    <th>Spent</th>
                    <th>Income</th>
                    <th>Profit</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $trips; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trip): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td>
                            <a href="<?php echo e(route('admin.trips.show', $trip)); ?>"><strong class="name-truncate" title="<?php echo e($trip->name); ?>"><?php echo e($trip->name); ?></strong></a>
                            <br><small class="text-muted"><?php echo e($trip->start_date ? $trip->start_date->format('d-m-Y') : '-'); ?></small>
                        </td>
                        <td>
                            <?php if($trip->customer): ?>
                            <div>
                                <a href="<?php echo e(route('admin.customers.show', $trip->customer)); ?>" class="name-truncate" title="<?php echo e($trip->customer->name); ?>"><strong><?php echo e($trip->customer->name); ?></strong></a>
                                <br><small class="text-muted"><?php echo e($trip->customer->mobile); ?></small>
                                <br><small class="text-muted">Company: <?php echo e($trip->company->name ?? '-'); ?></small>
                            </div>
                            <?php else: ?>
                                <small class="text-muted">Company: <?php echo e($trip->company->name ?? '-'); ?></small>
                            <?php endif; ?>
                        </td>
                        <td><?php echo e(formatMoney($trip->budget)); ?></td>
                        <td class="<?php echo e($trip->add_on_total > 0 ? 'text-info' : 'text-muted'); ?>"><?php echo e(formatMoney($trip->add_on_total)); ?></td>
                        <td class="text-danger"><?php echo e(formatMoney($trip->total_spent)); ?></td>
                        <td class="text-success"><?php echo e(formatMoney($trip->total_income)); ?></td>
                        <td class="<?php echo e($trip->profit >= 0 ? 'text-success' : 'text-danger'); ?>"><strong><?php echo e(formatMoney($trip->profit)); ?></strong></td>
                        <td>
                            <?php
                                $statusColors = [
                                    'planning' => 'bg-secondary',
                                    'in_progress' => 'bg-warning',
                                    'on_hold' => 'bg-info',
                                    'completed' => 'bg-success',
                                    'cancelled' => 'bg-danger',
                                ];
                                $statusLabels = [
                                    'planning' => 'Planning',
                                    'in_progress' => 'In Progress',
                                    'on_hold' => 'On Hold',
                                    'completed' => 'Completed',
                                    'cancelled' => 'Cancelled',
                                ];
                            ?>
                            <span class="badge <?php echo e($statusColors[$trip->status] ?? 'bg-secondary'); ?>">
                                <?php echo e($statusLabels[$trip->status] ?? ucfirst($trip->status)); ?>

                            </span>
                        </td>
                        <td>
                            <div class="btn-group-actions">
                                <?php if($trip->trashed()): ?>
                                    <?php if(auth()->user()->hasPermission('trips', 'delete')): ?>
                                    <form action="<?php echo e(route('admin.trips.restore', $trip->id)); ?>" method="POST" class="d-inline">
                                        <?php echo csrf_field(); ?>
                                        <button type="submit" class="btn btn-sm btn-outline-success" title="Restore">
                                            <i class="bi bi-arrow-counterclockwise"></i>
                                        </button>
                                    </form>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <?php if(auth()->user()->hasPermission('trips', 'edit')): ?>
                                    <a href="<?php echo e(route('admin.trips.edit', $trip)); ?>" class="btn btn-sm btn-outline-primary" title="Edit">
                                        <i class="bi bi-pencil"></i>
                                    </a>
                                    <?php endif; ?>
                                    <a href="<?php echo e(route('admin.trips.show', $trip)); ?>" class="btn btn-sm btn-outline-info" title="View">
                                        <i class="bi bi-eye"></i>
                                    </a>
                                    <?php if(auth()->user()->hasPermission('trips', 'delete')): ?>
                                    <form action="<?php echo e(route('admin.trips.destroy', $trip)); ?>" method="POST" class="d-inline" onsubmit="return confirm('Delete this trip?')">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-sm btn-outline-danger" title="Delete">
                                            <i class="bi bi-archive"></i>
                                        </button>
                                    </form>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="10" class="empty-state">
                            <i class="bi bi-kanban"></i>
                            No trips found.
                        </td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
    </div>
    <div class="card-footer">
        <?php echo $__env->make('partials.pagination', ['paginator' => $trips], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('styles'); ?>
<style>
    .trip-filter-select {
        background-color: #6f42c1 !important;
        color: #fff !important;
        border: none !important;
        font-weight: 600;
        padding: 8px 35px 8px 15px;
        border-radius: 6px;
        cursor: pointer;
        min-width: 160px;
    }
    .trip-filter-select:focus {
        box-shadow: 0 0 0 3px rgba(111, 66, 193, 0.4) !important;
    }
    .trip-filter-select option {
        background-color: #fff;
        color: #333;
        padding: 10px;
    }
    .card-header .form-control {
        background-color: #fff !important;
        color: #333 !important;
    }
</style>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Workspace\tripcrm\resources\views/admin/trips/index.blade.php ENDPATH**/ ?>