<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <title>Invoice <?php echo e($invoice->invoice_number); ?></title>
    <style>
        @page {
            size: A4;
            margin: 25mm 20mm;
        }
        body {
            font-family: DejaVu Sans, Helvetica, Arial, sans-serif;
            font-size: 12px;
            line-height: 1.4;
            color: #333;
            margin: 0;
            padding: 0;
        }
        .clearfix:after {
            content: "";
            display: table;
            clear: both;
        }

        
        .header {
            margin-bottom: 30px;
            padding-bottom: 20px;
            border-bottom: 3px solid #405189;
        }
        .company-section {
            float: left;
            width: 50%;
        }
        .invoice-section {
            float: right;
            width: 50%;
            text-align: right;
        }
        .company-name {
            font-size: 22px;
            font-weight: bold;
            color: #333;
            margin-bottom: 5px;
        }
        .company-info {
            font-size: 12px;
            color: #666;
        }
        .invoice-title {
            font-size: 28px;
            font-weight: bold;
            color: #405189;
            margin-bottom: 8px;
        }
        .invoice-details {
            font-size: 12px;
            color: #333;
        }
        .status-badge {
            display: inline-block;
            margin-top: 10px;
            padding: 5px 15px;
            background-color: #405189;
            color: #fff;
            font-size: 11px;
            font-weight: bold;
            border-radius: 4px;
        }

        
        .info-row {
            margin-bottom: 25px;
        }
        .bill-to-section {
            float: left;
            width: 50%;
        }
        .trip-section {
            float: right;
            width: 45%;
        }
        .section-label {
            font-size: 11px;
            font-weight: bold;
            color: #888;
            text-transform: uppercase;
            margin-bottom: 8px;
        }
        .customer-name {
            font-size: 16px;
            font-weight: bold;
            color: #333;
            margin-bottom: 5px;
            word-wrap: break-word;
            overflow-wrap: break-word;
            max-width: 250px;
        }
        .customer-info {
            font-size: 12px;
            color: #555;
            line-height: 1.6;
            word-wrap: break-word;
            overflow-wrap: break-word;
            max-width: 250px;
        }

        
        .summary-row {
            margin-top: 20px;
        }
        .notes-section {
            float: left;
            width: 45%;
        }
        .totals-section {
            float: right;
            width: 50%;
        }
        .notes-title {
            font-size: 13px;
            font-weight: bold;
            color: #333;
            margin-bottom: 8px;
        }
        .notes-text {
            font-size: 11px;
            color: #666;
            line-height: 1.6;
        }

        
        .pdf-info {
            background-color: #f8f9fa;
            border: 1px solid #ddd;
            border-left: 3px solid #405189;
            padding: 15px;
            margin-bottom: 25px;
        }
        .pdf-info-title {
            font-weight: bold;
            color: #333;
            margin-bottom: 5px;
        }
        .pdf-info-text {
            color: #666;
            font-size: 11px;
        }

        
        .footer {
            margin-top: 60px;
            text-align: right;
        }
        .signature-box {
            display: inline-block;
            text-align: center;
            border-top: 1px solid #333;
            padding-top: 10px;
            min-width: 180px;
        }
        .signature-company {
            font-size: 12px;
            font-weight: bold;
            color: #405189;
        }
        .signature-text {
            font-size: 11px;
            color: #888;
            margin-top: 3px;
        }
    </style>
</head>
<body>
    
    <div class="header clearfix">
        <div class="company-section">
            <div class="company-name"><?php echo e($invoice->company->name ?? ''); ?></div>
            <div class="company-info">
                <?php if($invoice->company): ?>
                    <?php if($invoice->company->address): ?><?php echo e($invoice->company->address); ?><br><?php endif; ?>
                    <?php if($invoice->company->phone): ?>Phone: <?php echo e($invoice->company->phone); ?><br><?php endif; ?>
                    <?php if($invoice->company->email): ?>Email: <?php echo e($invoice->company->email); ?><br><?php endif; ?>
                    <?php if($invoice->company->gst_number): ?>GST: <?php echo e($invoice->company->gst_number); ?><?php endif; ?>
                <?php endif; ?>
            </div>
        </div>
        <div class="invoice-section">
            <div class="invoice-title">TAX INVOICE</div>
            <div class="invoice-details">
                <strong>Invoice #:</strong> <?php echo e($invoice->invoice_number); ?><br>
                <strong>Date:</strong> <?php echo e(\Carbon\Carbon::parse($invoice->date)->format('d-m-Y')); ?>

                <?php if($invoice->due_date): ?>
                <br><strong>Due Date:</strong> <?php echo e(\Carbon\Carbon::parse($invoice->due_date)->format('d-m-Y')); ?>

                <?php endif; ?>
            </div>
            <span class="status-badge"><?php echo e(strtoupper($invoice->status)); ?></span>
        </div>
    </div>

    
    <div class="info-row clearfix">
        <div class="bill-to-section">
            <div class="section-label">BILL TO:</div>
            <div class="customer-name"><?php echo e($invoice->customer->name ?? '-'); ?></div>
            <div class="customer-info">
                <?php if($invoice->customer): ?>
                    <?php if($invoice->customer->address): ?><?php echo e($invoice->customer->address); ?><br><?php endif; ?>
                    <?php if($invoice->customer->mobile): ?>Phone: <?php echo e($invoice->customer->mobile); ?><br><?php endif; ?>
                    <?php if($invoice->customer->gst_number): ?>GST: <?php echo e($invoice->customer->gst_number); ?><?php endif; ?>
                <?php endif; ?>
            </div>
        </div>
        <?php if($invoice->trip): ?>
        <div class="trip-section">
            <div class="section-label">TRIP:</div>
            <div style="font-size: 14px; font-weight: bold; color: #333;"><?php echo e($invoice->trip->trip_number); ?></div>
            <div style="font-size: 12px; color: #555;"><?php echo e($invoice->trip->name); ?></div>
        </div>
        <?php endif; ?>
    </div>

    
    <?php if($invoice->invoice_type == 'items' && $invoice->items && count($invoice->items) > 0): ?>
    <?php
        $hasDimensions = collect($invoice->items)->contains(function ($item) {
            return strtolower($item['unit'] ?? '') === 'sqft' || ($item['height'] ?? '') !== '' || ($item['width'] ?? '') !== '' || ($item['total'] ?? '') !== '';
        });

        $formatDimension = function ($value) {
            if ($value === null || $value === '') {
                return '-';
            }

            return rtrim(rtrim(number_format((float) $value, 2, '.', ''), '0'), '.');
        };

        // Per-line tax rollup (GST/VAT summed across line items).
        $lineTaxByType = ['gst' => 0, 'vat' => 0];
        $hasLineTax = false;
        foreach ($invoice->items as $taxItem) {
            $tType = $taxItem['tax_type'] ?? 'none';
            $tRate = (float) ($taxItem['tax_rate'] ?? 0);
            if ($tType === 'none' || $tRate <= 0) {
                continue;
            }
            $tAmount = $taxItem['amount'] ?? null;
            if ($tAmount === null || $tAmount === '') {
                $tAmount = strtolower($taxItem['unit'] ?? '') === 'sqft'
                    ? ($taxItem['total'] ?? 0) * ($taxItem['qty'] ?? 0) * ($taxItem['rate'] ?? 0)
                    : ($taxItem['qty'] ?? 0) * ($taxItem['rate'] ?? 0);
            }
            $tAmount = (float) $tAmount;
            $hasLineTax = true;
            if ($tType === 'gst') {
                $lineTaxByType['gst'] += $invoice->gst_inclusive
                    ? ($tAmount * $tRate) / (100 + $tRate)
                    : ($tAmount * $tRate) / 100;
            } else {
                $lineTaxByType['vat'] += ($tAmount * $tRate) / 100;
            }
        }
    ?>
    <table border="1" cellpadding="10" cellspacing="0" style="width: 100%; border-collapse: collapse; margin-bottom: 25px; border-color: #ccc;">
        <thead>
            <tr style="background-color: #405189; color: #fff;">
                <th style="width: <?php echo e($hasDimensions ? '4%' : '5%'); ?>; text-align: center; padding: 10px; font-size: 11px; font-weight: bold; border: 1px solid #ccc;">#</th>
                <th style="width: <?php echo e($hasDimensions ? '27%' : '35%'); ?>; text-align: left; padding: 10px; font-size: 11px; font-weight: bold; border: 1px solid #ccc;">DESCRIPTION</th>
                <th style="width: <?php echo e($hasDimensions ? '8%' : '10%'); ?>; text-align: center; padding: 10px; font-size: 11px; font-weight: bold; border: 1px solid #ccc;">HSN</th>
                <th style="width: <?php echo e($hasDimensions ? '8%' : '10%'); ?>; text-align: center; padding: 10px; font-size: 11px; font-weight: bold; border: 1px solid #ccc;">UNIT</th>
                <?php if($hasDimensions): ?>
                <th style="width: 7%; text-align: right; padding: 10px; font-size: 11px; font-weight: bold; border: 1px solid #ccc;">HEIGHT</th>
                <th style="width: 7%; text-align: right; padding: 10px; font-size: 11px; font-weight: bold; border: 1px solid #ccc;">WIDTH</th>
                <th style="width: 7%; text-align: right; padding: 10px; font-size: 11px; font-weight: bold; border: 1px solid #ccc;">SQFT</th>
                <?php endif; ?>
                <th style="width: <?php echo e($hasDimensions ? '7%' : '10%'); ?>; text-align: right; padding: 10px; font-size: 11px; font-weight: bold; border: 1px solid #ccc;">QTY</th>
                <th style="width: <?php echo e($hasDimensions ? '11%' : '15%'); ?>; text-align: right; padding: 10px; font-size: 11px; font-weight: bold; border: 1px solid #ccc;">RATE (₹)</th>
                <th style="width: <?php echo e($hasDimensions ? '14%' : '15%'); ?>; text-align: right; padding: 10px; font-size: 11px; font-weight: bold; border: 1px solid #ccc;">AMOUNT (₹)</th>
                <?php if($hasLineTax): ?>
                <th style="width: 10%; text-align: right; padding: 10px; font-size: 11px; font-weight: bold; border: 1px solid #ccc;">TAX</th>
                <?php endif; ?>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $invoice->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $itemAmount = $item['amount'] ?? null;
                if ($itemAmount === null || $itemAmount === '') {
                    $itemAmount = strtolower($item['unit'] ?? '') === 'sqft'
                        ? ($item['total'] ?? 0) * ($item['qty'] ?? 0) * ($item['rate'] ?? 0)
                        : ($item['qty'] ?? 0) * ($item['rate'] ?? 0);
                }
            ?>
            <tr>
                <td style="text-align: center; padding: 10px; font-size: 12px; font-weight: bold; border: 1px solid #ccc;"><?php echo e($index + 1); ?></td>
                <td style="text-align: left; padding: 10px; font-size: 12px; border: 1px solid #ccc;"><?php if(!empty($item['service_name'])): ?><strong><?php echo e($item['service_name']); ?></strong><br><?php endif; ?><?php echo e($item['description'] ?? '-'); ?><?php if(!empty($item['passenger_type'])): ?><br><span style="font-size: 10px; color: #888;"><?php echo e($item['passenger_type']); ?></span><?php endif; ?></td>
                <td style="text-align: center; padding: 10px; font-size: 12px; border: 1px solid #ccc;"><?php echo e($item['hsn'] ?? '-'); ?></td>
                <td style="text-align: center; padding: 10px; font-size: 12px; border: 1px solid #ccc;"><?php echo e(strtoupper($item['unit'] ?? '-')); ?></td>
                <?php if($hasDimensions): ?>
                <td style="text-align: right; padding: 10px; font-size: 12px; border: 1px solid #ccc;"><?php echo e($formatDimension($item['height'] ?? null)); ?></td>
                <td style="text-align: right; padding: 10px; font-size: 12px; border: 1px solid #ccc;"><?php echo e($formatDimension($item['width'] ?? null)); ?></td>
                <td style="text-align: right; padding: 10px; font-size: 12px; border: 1px solid #ccc;"><?php echo e($formatDimension($item['total'] ?? null)); ?></td>
                <?php endif; ?>
                <td style="text-align: right; padding: 10px; font-size: 12px; border: 1px solid #ccc;"><?php echo e(number_format($item['qty'] ?? 0, 0)); ?></td>
                <td style="text-align: right; padding: 10px; font-size: 12px; border: 1px solid #ccc;"><?php echo e(number_format($item['rate'] ?? 0, 0)); ?></td>
                <td style="text-align: right; padding: 10px; font-size: 12px; border: 1px solid #ccc;"><?php echo e(number_format($itemAmount, 0)); ?></td>
                <?php if($hasLineTax): ?>
                <?php $rowTaxType = $item['tax_type'] ?? 'none'; $rowTaxRate = (float) ($item['tax_rate'] ?? 0); ?>
                <td style="text-align: right; padding: 10px; font-size: 12px; border: 1px solid #ccc;"><?php if($rowTaxType !== 'none' && $rowTaxRate > 0): ?><?php echo e(strtoupper($rowTaxType)); ?> <?php echo e(rtrim(rtrim(number_format($rowTaxRate, 2), '0'), '.')); ?>%<?php else: ?>-<?php endif; ?></td>
                <?php endif; ?>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <?php elseif($invoice->invoice_type == 'pdf'): ?>
    <div class="pdf-info">
        <div class="pdf-info-title">PDF Invoice Uploaded</div>
        <?php if($invoice->pdf_description): ?>
        <div class="pdf-info-text"><?php echo e($invoice->pdf_description); ?></div>
        <?php endif; ?>
    </div>
    <?php endif; ?>

    
    <div class="summary-row clearfix">
        <div class="notes-section">
            <?php if($invoice->notes): ?>
            <div class="notes-title">Notes:</div>
            <div class="notes-text"><?php echo e($invoice->notes); ?></div>
            <?php endif; ?>
        </div>
        <div class="totals-section">
            <table style="width: 100%; border-collapse: collapse;">
                <tr>
                    <td style="padding: 10px 8px; font-size: 13px; border-bottom: 1px solid #eee; text-align: right; color: #666; width: 60%;">Subtotal:</td>
                    <td style="padding: 10px 8px; font-size: 13px; border-bottom: 1px solid #eee; text-align: right; font-weight: bold; color: #333;">₹ <?php echo e(number_format($invoice->subtotal, 0)); ?></td>
                </tr>
                <?php if($invoice->discount > 0): ?>
                <tr>
                    <td style="padding: 10px 8px; font-size: 13px; border-bottom: 1px solid #eee; text-align: right; color: #666; width: 60%;">Discount:</td>
                    <td style="padding: 10px 8px; font-size: 13px; border-bottom: 1px solid #eee; text-align: right; font-weight: bold; color: #e74c3c;">- ₹ <?php echo e(number_format($invoice->discount, 0)); ?></td>
                </tr>
                <?php endif; ?>
                <?php $hasLineTax = $hasLineTax ?? false; $lineTaxByType = $lineTaxByType ?? ['gst' => 0, 'vat' => 0]; ?>
                <?php if($hasLineTax): ?>
                    <?php if($lineTaxByType['gst'] > 0): ?>
                        <?php if($invoice->gst_split): ?>
                        <tr>
                            <td style="padding: 10px 8px; font-size: 13px; border-bottom: 1px solid #eee; text-align: right; color: #666; width: 60%;">CGST<?php echo e($invoice->gst_inclusive ? ' - Inclusive' : ''); ?>:</td>
                            <td style="padding: 10px 8px; font-size: 13px; border-bottom: 1px solid #eee; text-align: right; font-weight: bold; color: <?php echo e($invoice->gst_inclusive ? '#333' : '#27ae60'); ?>;"><?php echo e($invoice->gst_inclusive ? '' : '+ '); ?>₹ <?php echo e(number_format($lineTaxByType['gst'] / 2, 0)); ?></td>
                        </tr>
                        <tr>
                            <td style="padding: 10px 8px; font-size: 13px; border-bottom: 1px solid #eee; text-align: right; color: #666; width: 60%;">SGST<?php echo e($invoice->gst_inclusive ? ' - Inclusive' : ''); ?>:</td>
                            <td style="padding: 10px 8px; font-size: 13px; border-bottom: 1px solid #eee; text-align: right; font-weight: bold; color: <?php echo e($invoice->gst_inclusive ? '#333' : '#27ae60'); ?>;"><?php echo e($invoice->gst_inclusive ? '' : '+ '); ?>₹ <?php echo e(number_format($lineTaxByType['gst'] / 2, 0)); ?></td>
                        </tr>
                        <?php else: ?>
                        <tr>
                            <td style="padding: 10px 8px; font-size: 13px; border-bottom: 1px solid #eee; text-align: right; color: #666; width: 60%;">GST<?php echo e($invoice->gst_inclusive ? ' - Inclusive' : ''); ?>:</td>
                            <td style="padding: 10px 8px; font-size: 13px; border-bottom: 1px solid #eee; text-align: right; font-weight: bold; color: <?php echo e($invoice->gst_inclusive ? '#333' : '#27ae60'); ?>;"><?php echo e($invoice->gst_inclusive ? '' : '+ '); ?>₹ <?php echo e(number_format($lineTaxByType['gst'], 0)); ?></td>
                        </tr>
                        <?php endif; ?>
                    <?php endif; ?>
                    <?php if($lineTaxByType['vat'] > 0): ?>
                    <tr>
                        <td style="padding: 10px 8px; font-size: 13px; border-bottom: 1px solid #eee; text-align: right; color: #666; width: 60%;">VAT:</td>
                        <td style="padding: 10px 8px; font-size: 13px; border-bottom: 1px solid #eee; text-align: right; font-weight: bold; color: #27ae60;">+ ₹ <?php echo e(number_format($lineTaxByType['vat'], 0)); ?></td>
                    </tr>
                    <?php endif; ?>
                <?php elseif($invoice->gst_percent > 0): ?>
                    <?php if($invoice->gst_split): ?>
                    <tr>
                        <td style="padding: 10px 8px; font-size: 13px; border-bottom: 1px solid #eee; text-align: right; color: #666; width: 60%;">CGST (<?php echo e($invoice->gst_percent / 2); ?>%)<?php echo e($invoice->gst_inclusive ? ' - Inclusive' : ''); ?>:</td>
                        <td style="padding: 10px 8px; font-size: 13px; border-bottom: 1px solid #eee; text-align: right; font-weight: bold; color: <?php echo e($invoice->gst_inclusive ? '#333' : '#27ae60'); ?>;"><?php echo e($invoice->gst_inclusive ? '' : '+ '); ?>₹ <?php echo e(number_format($invoice->gst / 2, 0)); ?></td>
                    </tr>
                    <tr>
                        <td style="padding: 10px 8px; font-size: 13px; border-bottom: 1px solid #eee; text-align: right; color: #666; width: 60%;">SGST (<?php echo e($invoice->gst_percent / 2); ?>%)<?php echo e($invoice->gst_inclusive ? ' - Inclusive' : ''); ?>:</td>
                        <td style="padding: 10px 8px; font-size: 13px; border-bottom: 1px solid #eee; text-align: right; font-weight: bold; color: <?php echo e($invoice->gst_inclusive ? '#333' : '#27ae60'); ?>;"><?php echo e($invoice->gst_inclusive ? '' : '+ '); ?>₹ <?php echo e(number_format($invoice->gst / 2, 0)); ?></td>
                    </tr>
                    <?php else: ?>
                    <tr>
                        <td style="padding: 10px 8px; font-size: 13px; border-bottom: 1px solid #eee; text-align: right; color: #666; width: 60%;">GST (<?php echo e($invoice->gst_percent); ?>%)<?php echo e($invoice->gst_inclusive ? ' - Inclusive' : ''); ?>:</td>
                        <td style="padding: 10px 8px; font-size: 13px; border-bottom: 1px solid #eee; text-align: right; font-weight: bold; color: <?php echo e($invoice->gst_inclusive ? '#333' : '#27ae60'); ?>;"><?php echo e($invoice->gst_inclusive ? '' : '+ '); ?>₹ <?php echo e(number_format($invoice->gst, 0)); ?></td>
                    </tr>
                    <?php endif; ?>
                <?php endif; ?>
                <tr style="background-color: #f0f4f8;">
                    <td style="padding: 12px 8px; font-size: 14px; text-align: right; font-weight: bold; color: #333;">Grand Total:</td>
                    <td style="padding: 12px 8px; font-size: 16px; text-align: right; font-weight: bold; color: #333; white-space: nowrap;">₹<?php echo e(number_format($invoice->grand_total, 0)); ?></td>
                </tr>
            </table>
        </div>
    </div>

    
    <?php if($invoice->amount_paid > 0 || $invoice->balance_due > 0): ?>
    <div style="margin-top: 30px; padding: 15px; background-color: #f8f9fa; border: 1px solid #ddd;">
        <table style="width: 100%;">
            <tr>
                <td style="width: 33%; text-align: center;">
                    <div style="font-size: 11px; color: #666;">Amount Paid</div>
                    <div style="font-size: 16px; font-weight: bold; color: #27ae60;">₹ <?php echo e(number_format($invoice->amount_paid, 0)); ?></div>
                </td>
                <td style="width: 33%; text-align: center;">
                    <div style="font-size: 11px; color: #666;">Balance Due</div>
                    <div style="font-size: 16px; font-weight: bold; color: <?php echo e($invoice->balance_due > 0 ? '#e74c3c' : '#27ae60'); ?>;">₹ <?php echo e(number_format($invoice->balance_due, 0)); ?></div>
                </td>
                <td style="width: 33%; text-align: center;">
                    <div style="font-size: 11px; color: #666;">Status</div>
                    <div style="font-size: 14px; font-weight: bold; color: #333;"><?php echo e(strtoupper($invoice->status)); ?></div>
                </td>
            </tr>
        </table>
    </div>
    <?php endif; ?>

    
    <div class="footer">
        <div class="signature-box">
            <div class="signature-company">For <?php echo e($invoice->company->name ?? ''); ?></div>
            <div class="signature-text">Authorized Signatory</div>
        </div>
    </div>
</body>
</html>
<?php /**PATH D:\Workspace\tripcrm\resources\views/admin/invoices/pdf.blade.php ENDPATH**/ ?>