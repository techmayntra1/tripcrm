<?php $__env->startSection('title', 'Edit Invoice'); ?>
<?php $__env->startSection('content'); ?>
<div class="app-page-title">
    <div class="page-title-wrapper">
        <div class="page-title-heading">
            <div class="page-title-icon">
                <i class="bi bi-pencil-square icon-gradient bg-grow-early"></i>
            </div>
            <div>
                Edit Invoice #<?php echo e($invoice->invoice_number); ?>

                <div class="page-title-subheading"><?php echo e($invoice->customer->name ?? 'Unknown Customer'); ?></div>
            </div>
        </div>
        <div class="page-title-actions">
            <?php if(isset($fromTrip) && $fromTrip): ?>
                <a href="<?php echo e(route('admin.trips.show', $fromTrip)); ?>" class="btn btn-outline-secondary">
                    <i class="bi bi-arrow-left me-1"></i> Back to Trip
                </a>
            <?php elseif($invoice->trip_id): ?>
                <a href="<?php echo e(route('admin.trips.show', $invoice->trip_id)); ?>" class="btn btn-outline-secondary">
                    <i class="bi bi-arrow-left me-1"></i> Back to Trip
                </a>
            <?php else: ?>
                <a href="<?php echo e(route('admin.invoices.show', $invoice)); ?>" class="btn btn-outline-secondary">
                    <i class="bi bi-arrow-left me-1"></i> Back
                </a>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php if($errors->any()): ?>
<div class="alert alert-danger alert-dismissible fade show" role="alert">
    <ul class="mb-0">
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
<?php endif; ?>
<style>
    select.form-select.is-invalid,
    input.form-control.is-invalid,
    textarea.form-control.is-invalid,
    .form-select.is-invalid,
    .form-control.is-invalid {
        border-color: #dc3545 !important;
    }
    select.form-select.is-invalid:focus,
    input.form-control.is-invalid:focus,
    textarea.form-control.is-invalid:focus,
    .form-select.is-invalid:focus,
    .form-control.is-invalid:focus {
        border-color: #dc3545 !important;
        box-shadow: 0 0 0 0.25rem rgba(220, 53, 69, 0.25) !important;
    }
</style>
<form action="<?php echo e(route('admin.invoices.update', $invoice)); ?>" method="POST" enctype="multipart/form-data" class="needs-validation" novalidate>
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
    <?php if(isset($fromTrip)): ?>
    <input type="hidden" name="from_trip" value="<?php echo e($fromTrip); ?>">
    <?php endif; ?>
    <div class="main-card mb-3 card">
        <div class="card-header">
            <i class="bi bi-info-circle me-2"></i> Invoice Details
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-3">
                    <div class="mb-3">
                        <label for="invoice_number" class="form-label">Invoice Number</label>
                        <input type="text" class="form-control" id="invoice_number" value="<?php echo e($invoice->invoice_number); ?>" readonly>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="mb-3">
                        <label for="date" class="form-label">Invoice Date <span class="text-danger">*</span></label>
                        <input type="date" class="form-control" id="date" name="date" value="<?php echo e(old('date', $invoice->date ? $invoice->date->format('Y-m-d') : '')); ?>" required>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="mb-3">
                        <label for="due_date" class="form-label">Due Date</label>
                        <input type="date" class="form-control" id="due_date" name="due_date" value="<?php echo e(old('due_date', $invoice->due_date ? $invoice->due_date->format('Y-m-d') : '')); ?>">
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="mb-3">
                        <label for="company" class="form-label">Company <span class="text-danger">*</span></label>
                        <select class="form-select" id="company" name="company_id" required>
                            <option value="" data-has-gst="0">Select Company</option>
                            <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($company->id); ?>" data-has-gst="<?php echo e(!empty($company->gst_number) ? '1' : '0'); ?>" <?php echo e(old('company_id', $invoice->company_id) == $company->id ? 'selected' : ''); ?>><?php echo e($company->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-3">
                    <div class="mb-3">
                        <label for="customer" class="form-label">Customer <span class="text-danger">*</span></label>
                        <select class="form-select" id="customer" name="customer_id" required>
                            <option value="">Select Customer</option>
                            <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($customer->id); ?>" <?php echo e(old('customer_id', $invoice->customer_id) == $customer->id ? 'selected' : ''); ?>><?php echo e($customer->name); ?><?php echo e($customer->mobile ? ' - '.$customer->mobile : ''); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="mb-3">
                        <label for="trip" class="form-label">Trip</label>
                        <select class="form-select" id="trip" name="trip_id">
                            <option value="">Select Trip (Optional)</option>
                            <?php $__currentLoopData = $trips; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trip): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($trip->id); ?>" data-customer="<?php echo e($trip->customer_id); ?>" <?php echo e(old('trip_id', $invoice->trip_id) == $trip->id ? 'selected' : ''); ?>><?php echo e($trip->trip_number); ?> - <?php echo e($trip->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="mb-3">
                        <label for="subject" class="form-label">Subject</label>
                        <input type="text" class="form-control" id="subject" name="subject" value="<?php echo e(old('subject', $invoice->subject)); ?>" placeholder="Invoice subject" maxlength="200">
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="mb-3">
                        <label for="status" class="form-label">Status</label>
                        <select class="form-select" id="status" name="status">
                            <option value="sent" <?php echo e(old('status', $invoice->status) == 'sent' ? 'selected' : ''); ?>>Sent</option>
                            <option value="partial" <?php echo e(old('status', $invoice->status) == 'partial' ? 'selected' : ''); ?>>Partial</option>
                            <option value="paid" <?php echo e(old('status', $invoice->status) == 'paid' ? 'selected' : ''); ?>>Paid</option>
                            <option value="overdue" <?php echo e(old('status', $invoice->status) == 'overdue' ? 'selected' : ''); ?>>Overdue</option>
                            <option value="cancelled" <?php echo e(old('status', $invoice->status) == 'cancelled' ? 'selected' : ''); ?>>Cancelled</option>
                        </select>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="main-card mb-3 card">
        <div class="card-header d-flex justify-content-between align-items-center">
            <div>
                <i class="bi bi-list-check me-2"></i> Invoice Items
            </div>
            <div class="d-flex align-items-center gap-3">
                <div class="btn-group" role="group">
                    <input type="radio" class="btn-check" name="invoice_type" id="typePdf" value="pdf" <?php echo e(old('invoice_type', $invoice->invoice_type) == 'pdf' ? 'checked' : ''); ?>>
                    <label class="btn btn-outline-primary btn-sm" for="typePdf">
                        <i class="bi bi-file-pdf me-1"></i> Upload PDF
                    </label>
                    <input type="radio" class="btn-check" name="invoice_type" id="typeItems" value="items" <?php echo e(old('invoice_type', $invoice->invoice_type) == 'items' ? 'checked' : ''); ?>>
                    <label class="btn btn-outline-primary btn-sm" for="typeItems">
                        <i class="bi bi-list-ul me-1"></i> Add Items
                    </label>
                </div>
                <button type="button" class="btn btn-sm btn-primary" id="addItemBtn" style="<?php echo e(old('invoice_type', $invoice->invoice_type) == 'items' ? '' : 'display: none;'); ?>">
                    <i class="bi bi-plus-lg me-1"></i> Add Item
                </button>
            </div>
        </div>
        <div class="card-body" id="pdfUploadSection" style="<?php echo e(old('invoice_type', $invoice->invoice_type) == 'pdf' ? '' : 'display: none;'); ?>">
            <div class="row align-items-end">
                <div class="col-md-5">
                    <div class="mb-3">
                        <label for="invoice_pdf" class="form-label">Upload Invoice PDF <?php if(!$invoice->invoice_pdf): ?><span class="text-danger">*</span><?php endif; ?></label>
                        <input type="file" class="form-control" id="invoice_pdf" name="invoice_pdf" accept=".pdf" <?php echo e(!$invoice->invoice_pdf && $invoice->invoice_type == 'pdf' ? 'required' : ''); ?>>
                        <div class="invalid-feedback">Please upload an invoice PDF</div>
                        <?php if($invoice->invoice_pdf): ?>
                            <small class="text-muted">Current: <a href="<?php echo e(asset('storage/'.$invoice->invoice_pdf)); ?>" target="_blank">View PDF</a>. Leave empty to keep existing PDF.</small>
                        <?php else: ?>
                            <small class="text-muted">Max 10MB. Upload your invoice document.</small>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="col-md-7">
                    <div class="mb-3">
                        <label for="pdf_description" class="form-label">Description</label>
                        <input type="text" class="form-control" id="pdf_description" name="pdf_description" value="<?php echo e(old('pdf_description', $invoice->pdf_description)); ?>" placeholder="Brief description of the invoice...">
                    </div>
                </div>
            </div>
        </div>
        <?php
            $hasSqft = false;
            if($invoice->items && count($invoice->items) > 0) {
                foreach($invoice->items as $item) {
                    if(strtolower($item['unit'] ?? '') === 'sqft' || ($item['height'] ?? '') !== '' || ($item['width'] ?? '') !== '' || ($item['total'] ?? '') !== '') {
                        $hasSqft = true;
                        break;
                    }
                }
            }
        ?>
        <div class="card-body p-0" id="manualItemsSection" style="<?php echo e(old('invoice_type', $invoice->invoice_type) == 'items' ? '' : 'display: none;'); ?>">
            <table class="table table-bordered mb-0" id="itemsTable">
                <thead class="table-light">
                    <tr>
                        <th width="40">#</th>
                        <th width="160">Service</th>
                        <th>Description <span class="text-danger">*</span></th>
                        <th width="100">HSN/SAC</th>
                        <th width="110">Unit</th>
                        <th width="110" class="sqft-col" style="<?php echo e($hasSqft ? '' : 'display:none;'); ?>">Height</th>
                        <th width="110" class="sqft-col" style="<?php echo e($hasSqft ? '' : 'display:none;'); ?>">Width</th>
                        <th width="110" class="sqft-col" style="<?php echo e($hasSqft ? '' : 'display:none;'); ?>">Total Sqft</th>
                        <th width="95">Qty <span class="text-danger">*</span></th>
                        <th width="100">Rate (₹)</th>
                        <th width="120">Amount (₹)</th>
                        <th width="110" class="tax-col" style="display:none;">Tax Type</th>
                        <th width="90" class="tax-col" style="display:none;">Tax %</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php if($invoice->items && count($invoice->items) > 0): ?>
                        <?php $__currentLoopData = $invoice->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="text-center"><?php echo e($index + 1); ?></td>
                            <?php $rowServiceId = old('items.'.$index.'.service_id', $item['service_id'] ?? ''); ?>
                            <td>
                                <select class="form-select form-select-sm service-select" name="items[<?php echo e($index); ?>][service_id]">
                                    <option value="">— None —</option>
                                    <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $svc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($svc->id); ?>" data-name="<?php echo e($svc->name); ?>" data-price="<?php echo e($svc->price); ?>" data-description="<?php echo e($svc->description); ?>" <?php echo e((string) $rowServiceId === (string) $svc->id ? 'selected' : ''); ?>><?php echo e($svc->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <input type="hidden" class="service-name" name="items[<?php echo e($index); ?>][service_name]" value="<?php echo e(old('items.'.$index.'.service_name', $item['service_name'] ?? '')); ?>">
                            </td>
                            <td><textarea class="form-control form-control-sm item-description" name="items[<?php echo e($index); ?>][description]" placeholder="Item description" maxlength="150" rows="1"><?php echo e(old('items.'.$index.'.description', $item['description'] ?? '')); ?></textarea></td>
                            <td><input type="text" class="form-control form-control-sm" name="items[<?php echo e($index); ?>][hsn]" value="<?php echo e(old('items.'.$index.'.hsn', $item['hsn'] ?? '')); ?>" placeholder="HSN"></td>
                            <td>
                                <select class="form-select form-select-sm unit-select" name="items[<?php echo e($index); ?>][unit]">
                                    <?php $__currentLoopData = $units; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($unit->short_name); ?>" <?php echo e(old('items.'.$index.'.unit', $item['unit'] ?? '') == $unit->short_name ? 'selected' : ''); ?>><?php echo e($unit->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </td>
                            <td class="sqft-col" style="<?php echo e($hasSqft ? '' : 'display:none;'); ?>"><input type="number" class="form-control form-control-sm item-height" name="items[<?php echo e($index); ?>][height]" value="<?php echo e(old('items.'.$index.'.height', $item['height'] ?? '')); ?>" placeholder="0" min="0" step="0.01" inputmode="decimal"></td>
                            <td class="sqft-col" style="<?php echo e($hasSqft ? '' : 'display:none;'); ?>"><input type="number" class="form-control form-control-sm item-width" name="items[<?php echo e($index); ?>][width]" value="<?php echo e(old('items.'.$index.'.width', $item['width'] ?? '')); ?>" placeholder="0" min="0" step="0.01" inputmode="decimal"></td>
                            <td class="sqft-col" style="<?php echo e($hasSqft ? '' : 'display:none;'); ?>"><input type="number" class="form-control form-control-sm item-total" name="items[<?php echo e($index); ?>][total]" value="<?php echo e(old('items.'.$index.'.total', $item['total'] ?? '')); ?>" placeholder="0" min="0" step="0.01" inputmode="decimal"></td>
                            <td><input type="number" class="form-control form-control-sm qty" name="items[<?php echo e($index); ?>][qty]" value="<?php echo e(old('items.'.$index.'.qty', $item['qty'] ?? 1)); ?>" min="1" max="99999" step="1" inputmode="numeric"></td>
                            <td><input type="number" class="form-control form-control-sm rate" name="items[<?php echo e($index); ?>][rate]" value="<?php echo e(old('items.'.$index.'.rate', $item['rate'] ?? 0)); ?>" min="0" max="999999999" step="1" inputmode="numeric"></td>
                            <td><input type="number" class="form-control form-control-sm amount" name="items[<?php echo e($index); ?>][amount]" value="<?php echo e(old('items.'.$index.'.amount', $item['amount'] ?? round(($item['qty'] ?? 0) * ($item['rate'] ?? 0)))); ?>" min="0" step="1" inputmode="numeric"><?php if(!empty($item['passenger_type'])): ?><input type="hidden" name="items[<?php echo e($index); ?>][passenger_type]" value="<?php echo e(old('items.'.$index.'.passenger_type', $item['passenger_type'])); ?>"><?php endif; ?></td>
                            <?php $rowTaxType = old('items.'.$index.'.tax_type', $item['tax_type'] ?? 'gst'); ?>
                            <td class="tax-col" style="display:none;">
                                <select class="form-select form-select-sm tax-type" name="items[<?php echo e($index); ?>][tax_type]">
                                    <option value="none" <?php echo e($rowTaxType == 'none' ? 'selected' : ''); ?>>None</option>
                                    <option value="gst" <?php echo e($rowTaxType == 'gst' ? 'selected' : ''); ?>>GST</option>
                                    <option value="vat" <?php echo e($rowTaxType == 'vat' ? 'selected' : ''); ?>>VAT</option>
                                </select>
                            </td>
                            <td class="tax-col" style="display:none;"><input type="number" class="form-control form-control-sm tax-rate" name="items[<?php echo e($index); ?>][tax_rate]" value="<?php echo e(old('items.'.$index.'.tax_rate', $item['tax_rate'] ?? 18)); ?>" min="0" max="100" step="0.01" inputmode="decimal"></td>
                            <td class="text-center"><button type="button" class="btn btn-sm btn-outline-danger remove-row"><i class="bi bi-trash"></i></button></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <tr>
                            <td class="text-center">1</td>
                            <td>
                                <select class="form-select form-select-sm service-select" name="items[0][service_id]">
                                    <option value="">— None —</option>
                                    <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $svc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($svc->id); ?>" data-name="<?php echo e($svc->name); ?>" data-price="<?php echo e($svc->price); ?>" data-description="<?php echo e($svc->description); ?>"><?php echo e($svc->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <input type="hidden" class="service-name" name="items[0][service_name]" value="">
                            </td>
                            <td><textarea class="form-control form-control-sm item-description" name="items[0][description]" placeholder="Item description" maxlength="150" rows="1"></textarea></td>
                            <td><input type="text" class="form-control form-control-sm" name="items[0][hsn]" placeholder="HSN"></td>
                            <td>
                                <select class="form-select form-select-sm unit-select" name="items[0][unit]">
                                    <?php $__currentLoopData = $units; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($unit->short_name); ?>"><?php echo e($unit->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </td>
                            <td class="sqft-col" style="display:none;"><input type="number" class="form-control form-control-sm item-height" name="items[0][height]" placeholder="0" min="0" step="0.01" inputmode="decimal"></td>
                            <td class="sqft-col" style="display:none;"><input type="number" class="form-control form-control-sm item-width" name="items[0][width]" placeholder="0" min="0" step="0.01" inputmode="decimal"></td>
                            <td class="sqft-col" style="display:none;"><input type="number" class="form-control form-control-sm item-total" name="items[0][total]" placeholder="0" min="0" step="0.01" inputmode="decimal"></td>
                            <td><input type="number" class="form-control form-control-sm qty" name="items[0][qty]" value="1" min="1" max="99999" step="1" inputmode="numeric"></td>
                            <td><input type="number" class="form-control form-control-sm rate" name="items[0][rate]" placeholder="0" min="0" max="999999999" step="1" inputmode="numeric"></td>
                            <td><input type="number" class="form-control form-control-sm amount" name="items[0][amount]" placeholder="0" min="0" step="1" inputmode="numeric"></td>
                            <td class="tax-col" style="display:none;">
                                <select class="form-select form-select-sm tax-type" name="items[0][tax_type]">
                                    <option value="none">None</option>
                                    <option value="gst" selected>GST</option>
                                    <option value="vat">VAT</option>
                                </select>
                            </td>
                            <td class="tax-col" style="display:none;"><input type="number" class="form-control form-control-sm tax-rate" name="items[0][tax_rate]" value="18" min="0" max="100" step="0.01" inputmode="decimal"></td>
                            <td class="text-center"><button type="button" class="btn btn-sm btn-outline-danger remove-row"><i class="bi bi-trash"></i></button></td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    <div class="row" id="summaryRow">
        <div class="col-md-6">
            <div class="main-card mb-3 card">
                <div class="card-header">
                    <i class="bi bi-card-text me-2"></i> Notes
                </div>
                <div class="card-body">
                    <textarea class="form-control" name="notes" rows="4" maxlength="150"><?php echo e(old('notes', $invoice->notes)); ?></textarea>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="main-card mb-3 card">
                <div class="card-header">
                    <i class="bi bi-calculator me-2"></i> Summary
                </div>
                <div class="card-body">
                    <table class="table table-borderless mb-0">
                        <tr>
                            <td class="py-2">Subtotal</td>
                            <td class="py-2">
                                <div class="input-group">
                                    <span class="input-group-text">₹</span>
                                    <input type="number" class="form-control" name="subtotal" id="subtotalInput" value="<?php echo e(old('subtotal', $invoice->subtotal ?? 0)); ?>" min="0" max="999999999" step="1" inputmode="numeric">
                                </div>
                            </td>
                        </tr>
                        <tr>
                            <td class="py-2">Discount</td>
                            <td class="py-2">
                                <div class="input-group">
                                    <span class="input-group-text">₹</span>
                                    <input type="number" class="form-control" name="discount" id="discountInput" value="<?php echo e(old('discount', $invoice->discount ?? 0)); ?>" min="0" max="999999999" step="1" inputmode="numeric">
                                </div>
                            </td>
                        </tr>
                        <tr id="gstRow">
                            <td class="py-2" id="gstLabel">GST</td>
                            <td class="py-2">
                                <div class="input-group">
                                    <span class="input-group-text d-none" id="gstPerLineNote" style="font-size:12px;">Per line</span>
                                    <select class="form-select" style="max-width: 140px;" name="gst_percent" id="gstPercent">
                                        <?php $__currentLoopData = $gstRates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($rate->percentage); ?>" <?php echo e(old('gst_percent', $invoice->gst_percent) == $rate->percentage ? 'selected' : ''); ?>><?php echo e($rate->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <span class="input-group-text <?php echo e(old('gst_inclusive', $invoice->gst_inclusive) ? '' : 'text-success'); ?>" id="gstSign"><?php echo e(old('gst_inclusive', $invoice->gst_inclusive) ? '₹' : '+ ₹'); ?></span>
                                    <input type="number" class="form-control" name="gst" id="gstInput" value="<?php echo e(old('gst', $invoice->gst ?? 0)); ?>" readonly style="background-color: #e9ecef;">
                                </div>
                                <div class="row g-2 mt-2" id="gstSplitDisplay" style="display: <?php echo e(old('gst_split', $invoice->gst_split) ? '' : 'none'); ?>;">
                                    <div class="col-6">
                                        <div class="input-group input-group-sm">
                                            <span class="input-group-text">CGST</span>
                                            <input type="number" class="form-control" id="cgstDisplay" value="<?php echo e(round(($invoice->gst ?? 0) / 2)); ?>" readonly style="background-color: #e9ecef;">
                                        </div>
                                    </div>
                                    <div class="col-6">
                                        <div class="input-group input-group-sm">
                                            <span class="input-group-text">SGST</span>
                                            <input type="number" class="form-control" id="sgstDisplay" value="<?php echo e(round(($invoice->gst ?? 0) / 2)); ?>" readonly style="background-color: #e9ecef;">
                                        </div>
                                    </div>
                                </div>
                                <div class="d-flex flex-wrap gap-3 mt-2">
                                    <div class="form-check form-switch">
                                        <input class="form-check-input" type="checkbox" name="gst_inclusive" id="gstInclusive" value="1" <?php echo e(old('gst_inclusive', $invoice->gst_inclusive) ? 'checked' : ''); ?>>
                                        <label class="form-check-label small" for="gstInclusive">GST Inclusive</label>
                                    </div>
                                    <div class="form-check form-switch">
                                        <input class="form-check-input" type="checkbox" name="gst_split" id="gstSplit" value="1" <?php echo e(old('gst_split', $invoice->gst_split) ? 'checked' : ''); ?>>
                                        <label class="form-check-label small" for="gstSplit">Split SGST + CGST</label>
                                    </div>
                                </div>
                            </td>
                        </tr>
                        <tr>
                            <td class="py-2"><strong>Grand Total</strong></td>
                            <td class="py-2">
                                <div class="input-group">
                                    <span class="input-group-text">₹</span>
                                    <input type="number" class="form-control fw-bold" name="grand_total" id="grandTotalInput" value="<?php echo e(old('grand_total', $invoice->grand_total ?? 0)); ?>" min="0" max="999999999" step="1" inputmode="numeric">
                                </div>
                            </td>
                        </tr>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <div class="d-flex justify-content-end gap-2 mb-4">
        <a href="<?php echo e(route('admin.invoices.show', $invoice)); ?>" class="btn btn-outline-secondary">Cancel</a>
        <button type="submit" class="btn btn-primary">
            <i class="bi bi-check-lg me-1"></i> Update Invoice
        </button>
    </div>
</form>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
<script>
document.addEventListener('DOMContentLoaded', function() {
    const typeItems = document.getElementById('typeItems');
    const typePdf = document.getElementById('typePdf');
    const companySelect = document.getElementById('company');
    const gstRow = document.getElementById('gstRow');
    const itemsTableBody = document.querySelector('#itemsTable tbody');
    const manualItemsSection = document.getElementById('manualItemsSection');
    const pdfUploadSection = document.getElementById('pdfUploadSection');
    const addItemBtn = document.getElementById('addItemBtn');
    const customerSelect = document.getElementById('customer');
    const tripSelect = document.getElementById('trip');
    let itemIndex = itemsTableBody.querySelectorAll('tr').length;

    // ----- Customer <-> Trip linking -----
    const tripOptions = Array.from(tripSelect.options);

    function filterTripsByCustomer(customerId) {
        let currentStillValid = false;
        tripOptions.forEach(function(opt) {
            if (!opt.value) { opt.hidden = false; return; }
            const belongs = !customerId || opt.getAttribute('data-customer') === String(customerId);
            opt.hidden = !belongs;
            if (belongs && opt.value === tripSelect.value) currentStillValid = true;
        });
        if (tripSelect.value && !currentStillValid) tripSelect.value = '';
    }

    function lockCustomer(customerId) {
        if (!customerId) return;
        customerSelect.value = String(customerId);
        customerSelect.disabled = true;
        let hidden = document.getElementById('customerHidden');
        if (!hidden) {
            hidden = document.createElement('input');
            hidden.type = 'hidden';
            hidden.name = 'customer_id';
            hidden.id = 'customerHidden';
            customerSelect.parentNode.appendChild(hidden);
        }
        hidden.value = String(customerId);
        customerSelect.classList.remove('is-invalid');
    }

    function unlockCustomer() {
        customerSelect.disabled = false;
        const hidden = document.getElementById('customerHidden');
        if (hidden) hidden.remove();
    }

    customerSelect.addEventListener('change', function() {
        filterTripsByCustomer(this.value);
    });

    tripSelect.addEventListener('change', function() {
        if (this.value) {
            const opt = this.options[this.selectedIndex];
            lockCustomer(opt.getAttribute('data-customer'));
        } else {
            unlockCustomer();
        }
    });

    // Initial customer <-> trip sync
    if (tripSelect.value) {
        const opt = tripSelect.options[tripSelect.selectedIndex];
        lockCustomer(opt.getAttribute('data-customer'));
    } else if (customerSelect.value) {
        filterTripsByCustomer(customerSelect.value);
    }

    function updateGstVisibility() {
        const selectedOption = companySelect.options[companySelect.selectedIndex];
        const hasGst = selectedOption && selectedOption.getAttribute('data-has-gst') === '1';
        gstRow.style.display = hasGst ? '' : 'none';
        updateTaxColumns();
        updateSummaryTaxMode();
        calculateTotals();
    }

    function updateTaxColumns() {
        const show = typeItems.checked && gstRow.style.display !== 'none';
        document.querySelectorAll('.tax-col').forEach(function(el) {
            el.style.display = show ? '' : 'none';
        });
    }

    function updateSummaryTaxMode() {
        const perLine = typeItems.checked && gstRow.style.display !== 'none';
        const gstPercent = document.getElementById('gstPercent');
        const gstPerLineNote = document.getElementById('gstPerLineNote');
        const gstLabel = document.getElementById('gstLabel');
        if (gstPercent) gstPercent.classList.toggle('d-none', perLine);
        if (gstPerLineNote) gstPerLineNote.classList.toggle('d-none', !perLine);
        if (gstLabel) gstLabel.textContent = perLine ? 'Tax' : 'GST';
    }

    function calculateTotals() {
        let subtotal = 0;
        const subtotalInput = document.getElementById('subtotalInput');
        const grandTotalInput = document.getElementById('grandTotalInput');
        const gstInclusive = document.getElementById('gstInclusive').checked;
        const gstSign = document.getElementById('gstSign');
        const gstVisible = gstRow.style.display !== 'none';

        let gst, grandTotal, gstPortion;

        if (typeItems.checked) {
            // Items mode: per-line tax (GST/VAT summed across lines).
            let gstTax = 0, vatTax = 0;
            document.querySelectorAll('#itemsTable tbody tr').forEach(function(row) {
                const amt = parseFloat((row.querySelector('.amount') || {}).value) || 0;
                subtotal += amt;
                if (!gstVisible) return;
                const typeEl = row.querySelector('.tax-type');
                const rateEl = row.querySelector('.tax-rate');
                if (!typeEl || !rateEl) return;
                const type = typeEl.value;
                const rate = parseFloat(rateEl.value) || 0;
                if (rate <= 0 || type === 'none') return;
                if (type === 'gst') {
                    gstTax += gstInclusive ? (amt * rate) / (100 + rate) : (amt * rate) / 100;
                } else if (type === 'vat') {
                    vatTax += (amt * rate) / 100;
                }
            });
            subtotal = Math.min(Math.round(subtotal), 99999999);
            subtotalInput.value = subtotal;

            const discount = parseFloat(document.getElementById('discountInput').value) || 0;
            gstPortion = gstTax;
            gst = gstTax + vatTax;
            const addTax = vatTax + (gstInclusive ? 0 : gstTax);
            grandTotal = Math.round(subtotal - discount + addTax);
            gstSign.textContent = gstInclusive ? '₹' : '+ ₹';
            gstSign.classList.toggle('text-success', !gstInclusive);
        } else {
            subtotal = parseFloat(subtotalInput.value) || 0;
            const discount = parseFloat(document.getElementById('discountInput').value) || 0;
            const gstPercent = gstVisible ? (parseFloat(document.getElementById('gstPercent').value) || 0) : 0;
            const afterDiscount = subtotal - discount;

            if (gstInclusive && gstPercent > 0) {
                gst = (afterDiscount * gstPercent) / (100 + gstPercent);
                grandTotal = Math.round(afterDiscount);
                gstSign.textContent = '₹';
                gstSign.classList.remove('text-success');
            } else {
                gst = (afterDiscount * gstPercent) / 100;
                grandTotal = Math.round(afterDiscount + gst);
                gstSign.textContent = '+ ₹';
                gstSign.classList.add('text-success');
            }
            gstPortion = gst;
        }

        document.getElementById('gstInput').value = Math.round(gst);
        grandTotalInput.value = grandTotal;

        const splitOn = document.getElementById('gstSplit').checked;
        document.getElementById('gstSplitDisplay').style.display = splitOn ? '' : 'none';
        if (splitOn) {
            const half = Math.round(gstPortion / 2);
            document.getElementById('cgstDisplay').value = half;
            document.getElementById('sgstDisplay').value = half;
        }

        if (grandTotal > 99999999) {
            grandTotalInput.classList.add('is-invalid');
        } else {
            grandTotalInput.classList.remove('is-invalid');
        }

        if (subtotal > 99999999) {
            subtotalInput.classList.add('is-invalid');
        } else {
            subtotalInput.classList.remove('is-invalid');
        }
    }

    function reindexRows() {
        const rows = itemsTableBody.querySelectorAll('tr');
        rows.forEach(function(row, index) {
            row.querySelector('td:first-child').textContent = index + 1;
        });
        itemIndex = rows.length;
    }

    companySelect.addEventListener('change', updateGstVisibility);

    const pdfInput = document.getElementById('invoice_pdf');
    const hasExistingPdf = <?php echo e($invoice->invoice_pdf ? 'true' : 'false'); ?>;

    typeItems.addEventListener('change', function() {
        if (this.checked) {
            manualItemsSection.style.display = 'block';
            pdfUploadSection.style.display = 'none';
            addItemBtn.style.display = 'inline-block';
            pdfInput.removeAttribute('required');
            pdfInput.classList.remove('is-invalid');
            updateTaxColumns();
            updateSummaryTaxMode();
            calculateTotals();
        }
    });

    typePdf.addEventListener('change', function() {
        if (this.checked) {
            manualItemsSection.style.display = 'none';
            if (!hasExistingPdf) {
                pdfInput.setAttribute('required', 'required');
            }
            pdfUploadSection.style.display = 'block';
            addItemBtn.style.display = 'none';
            updateTaxColumns();
            updateSummaryTaxMode();
            calculateTotals();
        }
    });

    function hasSqftSelected() {
        const unitSelects = itemsTableBody.querySelectorAll('.unit-select');
        for (let i = 0; i < unitSelects.length; i++) {
            if (unitSelects[i].value.toLowerCase() === 'sqft') return true;
        }
        return false;
    }

    function toggleSqftColumns() {
        const show = hasSqftSelected();
        document.querySelectorAll('.sqft-col').forEach(function(el) {
            el.style.display = show ? '' : 'none';
        });
    }

    function calculateTotalSqft(row) {
        const heightInput = row.querySelector('.item-height');
        const widthInput = row.querySelector('.item-width');
        const totalInput = row.querySelector('.item-total');
        if (heightInput && widthInput && totalInput) {
            const height = parseFloat(heightInput.value) || 0;
            const width = parseFloat(widthInput.value) || 0;
            if (height > 0 && width > 0) {
                totalInput.value = (height * width).toFixed(2);
            }
        }
    }

    function calculateRowAmount(row) {
        const unitSelect = row.querySelector('.unit-select');
        const qty = parseFloat(row.querySelector('.qty').value) || 0;
        const rate = parseFloat(row.querySelector('.rate').value) || 0;
        const amountInput = row.querySelector('.amount');

        let amount;
        if (unitSelect && unitSelect.value.toLowerCase() === 'sqft') {
            const total = parseFloat(row.querySelector('.item-total').value) || 0;
            amount = total * qty * rate;
        } else {
            amount = qty * rate;
        }
        amountInput.value = Math.round(amount);
    }

    addItemBtn.addEventListener('click', function() {
        const showSqft = hasSqftSelected();
        const showTax = gstRow.style.display !== 'none';
        const newRow = `
            <tr>
                <td class="text-center">${itemIndex + 1}</td>
                <td>
                    <select class="form-select form-select-sm service-select" name="items[${itemIndex}][service_id]">
                        <option value="">— None —</option>
                        <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $svc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($svc->id); ?>" data-name="<?php echo e($svc->name); ?>" data-price="<?php echo e($svc->price); ?>" data-description="<?php echo e($svc->description); ?>"><?php echo e($svc->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <input type="hidden" class="service-name" name="items[${itemIndex}][service_name]" value="">
                </td>
                <td><textarea class="form-control form-control-sm item-description" name="items[${itemIndex}][description]" placeholder="Item description" maxlength="150" rows="1"></textarea></td>
                <td><input type="text" class="form-control form-control-sm" name="items[${itemIndex}][hsn]" placeholder="HSN"></td>
                <td>
                    <select class="form-select form-select-sm unit-select" name="items[${itemIndex}][unit]">
                        <?php $__currentLoopData = $units; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($unit->short_name); ?>"><?php echo e($unit->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </td>
                <td class="sqft-col" style="${showSqft ? '' : 'display:none;'}"><input type="number" class="form-control form-control-sm item-height" name="items[${itemIndex}][height]" placeholder="0" min="0" step="0.01" inputmode="decimal"></td>
                <td class="sqft-col" style="${showSqft ? '' : 'display:none;'}"><input type="number" class="form-control form-control-sm item-width" name="items[${itemIndex}][width]" placeholder="0" min="0" step="0.01" inputmode="decimal"></td>
                <td class="sqft-col" style="${showSqft ? '' : 'display:none;'}"><input type="number" class="form-control form-control-sm item-total" name="items[${itemIndex}][total]" placeholder="0" min="0" step="0.01" inputmode="decimal"></td>
                <td><input type="number" class="form-control form-control-sm qty" name="items[${itemIndex}][qty]" value="1" min="1" max="99999" step="1" inputmode="numeric"></td>
                <td><input type="number" class="form-control form-control-sm rate" name="items[${itemIndex}][rate]" placeholder="0" min="0" max="999999999" step="1" inputmode="numeric"></td>
                <td><input type="number" class="form-control form-control-sm amount" name="items[${itemIndex}][amount]" placeholder="0" min="0" step="1" inputmode="numeric"></td>
                <td class="tax-col" style="${showTax ? '' : 'display:none;'}">
                    <select class="form-select form-select-sm tax-type" name="items[${itemIndex}][tax_type]">
                        <option value="none">None</option>
                        <option value="gst" selected>GST</option>
                        <option value="vat">VAT</option>
                    </select>
                </td>
                <td class="tax-col" style="${showTax ? '' : 'display:none;'}"><input type="number" class="form-control form-control-sm tax-rate" name="items[${itemIndex}][tax_rate]" value="18" min="0" max="100" step="0.01" inputmode="decimal"></td>
                <td class="text-center"><button type="button" class="btn btn-sm btn-outline-danger remove-row"><i class="bi bi-trash"></i></button></td>
            </tr>
        `;
        itemsTableBody.insertAdjacentHTML('beforeend', newRow);
        itemIndex++;
        reindexRows();
    });

    itemsTableBody.addEventListener('click', function(e) {
        if (e.target.closest('.remove-row')) {
            const rows = itemsTableBody.querySelectorAll('tr');
            if (rows.length > 1) {
                e.target.closest('tr').remove();
                reindexRows();
                toggleSqftColumns();
                calculateTotals();
            }
        }
    });

    itemsTableBody.addEventListener('input', function(e) {
        if (e.target.classList.contains('item-height') || e.target.classList.contains('item-width')) {
            const row = e.target.closest('tr');
            calculateTotalSqft(row);
            calculateRowAmount(row);
            calculateTotals();
        }
        if (e.target.classList.contains('qty') || e.target.classList.contains('rate') || e.target.classList.contains('item-total')) {
            const row = e.target.closest('tr');
            calculateRowAmount(row);
            calculateTotals();
        }
        if (e.target.classList.contains('amount')) {
            calculateTotals();
        }
        if (e.target.classList.contains('tax-rate')) {
            calculateTotals();
        }
    });

    itemsTableBody.addEventListener('change', function(e) {
        if (e.target.classList.contains('unit-select')) {
            toggleSqftColumns();
            const row = e.target.closest('tr');
            calculateRowAmount(row);
            calculateTotals();
        }
        if (e.target.classList.contains('tax-type')) {
            calculateTotals();
        }
        if (e.target.classList.contains('service-select')) {
            const row = e.target.closest('tr');
            const opt = e.target.options[e.target.selectedIndex];
            const nameInput = row.querySelector('.service-name');
            if (nameInput) nameInput.value = e.target.value ? (opt.getAttribute('data-name') || '') : '';
            if (e.target.value) {
                const price = opt.getAttribute('data-price');
                const desc = opt.getAttribute('data-description');
                if (price !== null && price !== '') {
                    const rateEl = row.querySelector('.rate');
                    if (rateEl) rateEl.value = Math.round(parseFloat(price));
                }
                const descEl = row.querySelector('.item-description');
                if (descEl && desc) descEl.value = desc;
                calculateRowAmount(row);
            }
            calculateTotals();
        }
    });

    document.getElementById('subtotalInput').addEventListener('input', calculateTotals);
    document.getElementById('discountInput').addEventListener('input', calculateTotals);
    document.getElementById('gstPercent').addEventListener('change', calculateTotals);
    document.getElementById('gstInclusive').addEventListener('change', calculateTotals);
    document.getElementById('gstSplit').addEventListener('change', calculateTotals);

    function validateForm() {
        let isValid = true;
        document.querySelectorAll('.is-invalid').forEach(el => el.classList.remove('is-invalid'));

        const dateInput = document.getElementById('date');
        if (!dateInput.value) {
            dateInput.classList.add('is-invalid');
            isValid = false;
        }

        const companyInput = document.getElementById('company');
        if (companyInput.selectedIndex === 0 || !companyInput.value) {
            companyInput.classList.add('is-invalid');
            isValid = false;
        }

        const customerInput = document.getElementById('customer');
        if (customerInput.selectedIndex === 0 || !customerInput.value) {
            customerInput.classList.add('is-invalid');
            isValid = false;
        }

        const tripInput = document.getElementById('trip');
        if ((tripInput.selectedIndex === 0 || !tripInput.value) && !tripInput.disabled) {
            tripInput.classList.add('is-invalid');
            isValid = false;
        }

        const subtotalInput = document.getElementById('subtotalInput');
        const grandTotalInput = document.getElementById('grandTotalInput');
        const subtotal = parseFloat(subtotalInput.value) || 0;
        const grandTotal = parseFloat(grandTotalInput.value) || 0;

        if (subtotal <= 0 || subtotal > 99999999) {
            subtotalInput.classList.add('is-invalid');
            isValid = false;
        }

        if (grandTotal <= 0 || grandTotal > 99999999) {
            grandTotalInput.classList.add('is-invalid');
            isValid = false;
        }

        if (typePdf.checked && !hasExistingPdf && (!pdfInput.files || pdfInput.files.length === 0)) {
            pdfInput.classList.add('is-invalid');
            isValid = false;
        }

        if (typeItems.checked) {
            const rows = itemsTableBody.querySelectorAll('tr');
            rows.forEach(function(row) {
                const description = row.querySelector('textarea[name$="[description]"]');
                const qty = row.querySelector('input[name$="[qty]"]');
                const rate = row.querySelector('input[name$="[rate]"]');
                const unitSelect = row.querySelector('.unit-select');
                const isSqft = unitSelect && unitSelect.value.toLowerCase() === 'sqft';
                if (description && qty && rate) {
                    if (!description.value.trim()) {
                        description.classList.add('is-invalid');
                        isValid = false;
                    }
                    if ((parseFloat(qty.value) || 0) <= 0) {
                        qty.classList.add('is-invalid');
                        isValid = false;
                    }
                    if (!isSqft && (parseFloat(rate.value) || 0) <= 0) {
                        rate.classList.add('is-invalid');
                        isValid = false;
                    }
                }
            });
        }

        if (!isValid) {
            const firstError = document.querySelector('.is-invalid');
            if (firstError) {
                firstError.scrollIntoView({ behavior: 'smooth', block: 'center' });
                firstError.focus();
            }
        }

        return isValid;
    }

    document.querySelectorAll('form.needs-validation input, form.needs-validation select, form.needs-validation textarea').forEach(el => {
        el.addEventListener('input', function() {
            if (this.name === 'subtotal' || this.name === 'grand_total' || this.name === 'discount') {
                const num = parseFloat(this.value) || 0;
                if (this.name === 'discount') {
                    if (num >= 0 && num <= 99999999) this.classList.remove('is-invalid');
                } else {
                    if (num >= 1 && num <= 99999999) this.classList.remove('is-invalid');
                }
            } else if (this.value.trim()) {
                this.classList.remove('is-invalid');
            }
        });
        el.addEventListener('change', function() {
            if (this.name === 'subtotal' || this.name === 'grand_total' || this.name === 'discount') {
                const num = parseFloat(this.value) || 0;
                if (this.name === 'discount') {
                    if (num >= 0 && num <= 99999999) this.classList.remove('is-invalid');
                } else {
                    if (num >= 1 && num <= 99999999) this.classList.remove('is-invalid');
                }
            } else if (this.value.trim()) {
                this.classList.remove('is-invalid');
            }
        });
    });

    ['subtotalInput', 'discountInput', 'grandTotalInput'].forEach(id => {
        const input = document.getElementById(id);
        if (input) {
            input.addEventListener('keydown', function(e) {
                const val = this.value.replace(/[^0-9]/g, '');
                if ([8, 9, 13, 27, 46, 37, 38, 39, 40].includes(e.keyCode)) return;
                if ((e.ctrlKey || e.metaKey) && [65, 67, 86, 88].includes(e.keyCode)) return;
                if (val.length >= 8 && e.keyCode >= 48 && e.keyCode <= 57) {
                    e.preventDefault();
                }
                if (val.length >= 8 && e.keyCode >= 96 && e.keyCode <= 105) {
                    e.preventDefault();
                }
            });
            input.addEventListener('input', function() {
                let val = this.value.replace(/[^0-9]/g, '');
                if (val.length > 8) {
                    val = val.substring(0, 8);
                    this.value = val;
                }
            });
        }
    });
    
    document.querySelector('form.needs-validation').addEventListener('submit', function(e) {
        if (!validateForm()) {
            e.preventDefault();
            e.stopPropagation();
        }
    });

    updateSummaryTaxMode();
    updateGstVisibility();
});
</script>
<?php $__env->stopPush(); ?>
<?php $__env->startPush('styles'); ?>
<style>
.input-group .is-invalid ~ .invalid-feedback,
.input-group .is-invalid ~ .invalid-tooltip {
    display: block;
}
.input-group.has-validation .invalid-feedback {
    width: 100%;
}
#manualItemsSection {
    overflow-x: auto;
}
#itemsTable {
    min-width: 1080px;
}
#itemsTable .sqft-col {
    min-width: 110px;
}
#itemsTable .item-height,
#itemsTable .item-width,
#itemsTable .item-total,
#itemsTable .qty {
    min-width: 85px;
}
</style>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Workspace\tripcrm\resources\views/admin/invoices/edit.blade.php ENDPATH**/ ?>