<div class="d-flex align-items-center w-100">
    <div class="d-flex align-items-center gap-2">
        <span class="text-muted">Show</span>
        <select class="form-select form-select-sm" style="width: 80px;" onchange="window.location.href=this.options[this.selectedIndex].getAttribute('data-url')">
            <?php $__currentLoopData = [10, 15, 25, 50, 100]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option data-url="<?php echo e(request()->fullUrlWithQuery(['per_page' => $size, 'page' => 1])); ?>" <?php echo e(request()->input('per_page', 15) == $size ? 'selected' : ''); ?>><?php echo e($size); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <span class="text-muted">entries</span>
    </div>
    <div class="flex-grow-1 d-flex justify-content-center">
        <?php if($paginator->hasPages()): ?>
            <?php echo e($paginator->onEachSide(1)->links('pagination::bootstrap-5')); ?>

        <?php endif; ?>
    </div>
    <div>
        <span class="text-muted text-nowrap">Showing <?php echo e($paginator->firstItem() ?? 0); ?> to <?php echo e($paginator->lastItem() ?? 0); ?> of <?php echo e($paginator->total()); ?> entries</span>
    </div>
</div>
<?php /**PATH D:\Workspace\tripcrm\resources\views/partials/pagination.blade.php ENDPATH**/ ?>