@php $currencySymbol = currencySymbol($invoice); @endphp
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <title>Invoice {{ $invoice->invoice_number }}</title>
    <style>
        @page {
            size: A4;
            margin: 12mm 12mm;
        }
        body {
            font-family: DejaVu Sans, Helvetica, Arial, sans-serif;
            font-size: 10px;
            line-height: 1.3;
            color: #333;
            margin: 0;
            padding: 0;
        }
        .clearfix:after {
            content: "";
            display: table;
            clear: both;
        }

        
        .header {
            margin-bottom: 12px;
            padding-bottom: 8px;
            border-bottom: 2px solid #405189;
        }
        .company-section {
            float: left;
            width: 50%;
        }
        .invoice-section {
            float: right;
            width: 50%;
            text-align: right;
        }
        .company-name {
            font-size: 12px;
            font-weight: bold;
            color: #333;
            margin-bottom: 5px;
        }
        .company-logo {
            height: 45px;
            width: auto;
            margin-bottom: 4px;
        }
        .company-info {
            font-size: 10px;
            color: #666;
        }
        .invoice-title {
            font-size: 20px;
            font-weight: bold;
            color: #405189;
            margin-bottom: 4px;
        }
        .invoice-details {
            font-size: 10px;
            color: #333;
        }

        
        .info-row {
            margin-bottom: 12px;
        }
        .bill-to-section {
            float: left;
            width: 50%;
        }
        .trip-section {
            float: right;
            width: 45%;
        }
        .section-label {
            font-size: 9px;
            font-weight: bold;
            color: #888;
            text-transform: uppercase;
            margin-bottom: 4px;
        }
        .customer-name {
            font-size: 12px;
            font-weight: bold;
            color: #333;
            margin-bottom: 5px;
            word-wrap: break-word;
            overflow-wrap: break-word;
            max-width: 250px;
        }
        .customer-info {
            font-size: 10px;
            color: #555;
            line-height: 1.4;
            word-wrap: break-word;
            overflow-wrap: break-word;
            max-width: 250px;
        }

        
        .summary-row {
            margin-top: 8px;
        }
        .notes-section {
            float: left;
            width: 45%;
        }
        .totals-section {
            float: right;
            width: 50%;
        }
        .notes-title {
            font-size: 10px;
            font-weight: bold;
            color: #333;
            margin-bottom: 4px;
        }
        .notes-text {
            font-size: 9px;
            color: #666;
            line-height: 1.4;
        }

        
        .pdf-info {
            background-color: #f8f9fa;
            border: 1px solid #ddd;
            border-left: 3px solid #405189;
            padding: 8px;
            margin-bottom: 12px;
        }
        .pdf-info-title {
            font-weight: bold;
            color: #333;
            margin-bottom: 5px;
        }
        .pdf-info-text {
            color: #666;
            font-size: 9px;
        }

        
        .footer {
            margin-top: 25px;
            text-align: right;
        }
        .signature-box {
            display: inline-block;
            text-align: center;
            border-top: 1px solid #333;
            padding-top: 5px;
            min-width: 180px;
        }
        .signature-company {
            font-size: 10px;
            font-weight: bold;
            color: #405189;
        }
        .signature-text {
            font-size: 9px;
            color: #888;
            margin-top: 3px;
        }
    </style>
</head>
<body>
    
    <div class="header clearfix">
        <div class="company-section">
            @php $logoDataUri = $invoice->company?->logo_data_uri; @endphp
            @if($logoDataUri)
            <img src="{{ $logoDataUri }}" class="company-logo" alt="">
            @endif
            <div class="company-name">{{ $invoice->company->name ?? '' }}</div>
            <div class="company-info">
                @if($invoice->company)
                    @if($invoice->company->address){{ $invoice->company->address }}<br>@endif
                    @if($invoice->company->phone)Phone: {{ $invoice->company->phone }}<br>@endif
                    @if($invoice->company->email)Email: {{ $invoice->company->email }}<br>@endif
                    @if($invoice->company->gst_number)GST: {{ $invoice->company->gst_number }}@endif
                @endif
            </div>
        </div>
        <div class="invoice-section">
            <div class="invoice-title">TAX INVOICE</div>
            <div class="invoice-details">
                <strong>Invoice #:</strong> {{ $invoice->invoice_number }}<br>
                <strong>Date:</strong> {{ \Carbon\Carbon::parse($invoice->date)->format('d-m-Y') }}
                @if($invoice->due_date)
                <br><strong>Due Date:</strong> {{ \Carbon\Carbon::parse($invoice->due_date)->format('d-m-Y') }}
                @endif
            </div>
        </div>
    </div>

    
    <div class="info-row clearfix">
        <div class="bill-to-section">
            <div class="section-label">BILL TO:</div>
            @include('partials._pdf_bill_to', ['customer' => $invoice->customer])
        </div>
        @if($invoice->trip)
        <div class="trip-section">
            <div class="section-label">TRIP:</div>
            <div style="font-size: 11px; font-weight: bold; color: #333;">{{ $invoice->trip->trip_number }}</div>
            <div style="font-size: 10px; color: #555;">{{ $invoice->trip->name }}</div>
        </div>
        @endif
    </div>

    
    @if($invoice->invoice_type == 'items' && $invoice->items && count($invoice->items) > 0)
    @php
        $hasDimensions = collect($invoice->items)->contains(function ($item) {
            return strtolower($item['unit'] ?? '') === 'sqft' || ($item['height'] ?? '') !== '' || ($item['width'] ?? '') !== '' || ($item['total'] ?? '') !== '';
        });

        $formatDimension = function ($value) {
            if ($value === null || $value === '') {
                return '-';
            }

            return rtrim(rtrim(number_format((float) $value, 2, '.', ''), '0'), '.');
        };

        // Per-line tax rollup (GST/VAT summed across line items).
        $lineTaxByType = ['gst' => 0, 'vat' => 0];
        $hasLineTax = false;
        foreach ($invoice->items as $taxItem) {
            $tType = $taxItem['tax_type'] ?? 'none';
            $tRate = (float) ($taxItem['tax_rate'] ?? 0);
            if ($tType === 'none' || $tRate <= 0) {
                continue;
            }
            $tAmount = $taxItem['amount'] ?? null;
            if ($tAmount === null || $tAmount === '') {
                $tAmount = strtolower($taxItem['unit'] ?? '') === 'sqft'
                    ? ($taxItem['total'] ?? 0) * ($taxItem['qty'] ?? 0) * ($taxItem['rate'] ?? 0)
                    : ($taxItem['qty'] ?? 0) * ($taxItem['rate'] ?? 0);
            }
            $tAmount = (float) $tAmount;
            $hasLineTax = true;
            if ($tType === 'gst') {
                $lineTaxByType['gst'] += $invoice->gst_inclusive
                    ? ($tAmount * $tRate) / (100 + $tRate)
                    : ($tAmount * $tRate) / 100;
            } else {
                $lineTaxByType['vat'] += ($tAmount * $tRate) / 100;
            }
        }
    @endphp
    <table border="1" cellpadding="5" cellspacing="0" style="width: 100%; border-collapse: collapse; margin-bottom: 12px; border-color: #ccc;">
        <thead>
            <tr style="background-color: #405189; color: #fff;">
                <th style="width: {{ $hasDimensions ? '4%' : '5%' }}; text-align: center; padding: 5px 6px; font-size: 9px; font-weight: bold; border: 1px solid #ccc;">#</th>
                <th style="width: {{ $hasDimensions ? '27%' : '35%' }}; text-align: left; padding: 5px 6px; font-size: 9px; font-weight: bold; border: 1px solid #ccc;">DESCRIPTION</th>
                <th style="width: {{ $hasDimensions ? '8%' : '10%' }}; text-align: center; padding: 5px 6px; font-size: 9px; font-weight: bold; border: 1px solid #ccc;">HSN</th>
                <th style="width: {{ $hasDimensions ? '8%' : '10%' }}; text-align: center; padding: 5px 6px; font-size: 9px; font-weight: bold; border: 1px solid #ccc;">UNIT</th>
                @if($hasDimensions)
                <th style="width: 7%; text-align: right; padding: 5px 6px; font-size: 9px; font-weight: bold; border: 1px solid #ccc;">HEIGHT</th>
                <th style="width: 7%; text-align: right; padding: 5px 6px; font-size: 9px; font-weight: bold; border: 1px solid #ccc;">WIDTH</th>
                <th style="width: 7%; text-align: right; padding: 5px 6px; font-size: 9px; font-weight: bold; border: 1px solid #ccc;">SQFT</th>
                @endif
                <th style="width: {{ $hasDimensions ? '7%' : '10%' }}; text-align: right; padding: 5px 6px; font-size: 9px; font-weight: bold; border: 1px solid #ccc;">QTY</th>
                <th style="width: {{ $hasDimensions ? '11%' : '15%' }}; text-align: right; padding: 5px 6px; font-size: 9px; font-weight: bold; border: 1px solid #ccc;">RATE ({{ $currencySymbol }})</th>
                <th style="width: {{ $hasDimensions ? '14%' : '15%' }}; text-align: right; padding: 5px 6px; font-size: 9px; font-weight: bold; border: 1px solid #ccc;">AMOUNT ({{ $currencySymbol }})</th>
                @if($hasLineTax)
                <th style="width: 10%; text-align: right; padding: 5px 6px; font-size: 9px; font-weight: bold; border: 1px solid #ccc;">TAX</th>
                @endif
            </tr>
        </thead>
        <tbody>
            @foreach($invoice->items as $index => $item)
            @php
                $itemAmount = $item['amount'] ?? null;
                if ($itemAmount === null || $itemAmount === '') {
                    $itemAmount = strtolower($item['unit'] ?? '') === 'sqft'
                        ? ($item['total'] ?? 0) * ($item['qty'] ?? 0) * ($item['rate'] ?? 0)
                        : ($item['qty'] ?? 0) * ($item['rate'] ?? 0);
                }
            @endphp
            <tr>
                <td style="text-align: center; padding: 5px 6px; font-size: 10px; font-weight: bold; border: 1px solid #ccc;">{{ $index + 1 }}</td>
                <td style="text-align: left; padding: 5px 6px; font-size: 10px; border: 1px solid #ccc;">@if(!empty($item['service_name']))<strong>{{ $item['service_name'] }}</strong>@if(!empty($item['passenger_type'])) <span style="font-size: 8px; color: #888;">· {{ $item['passenger_type'] }}</span>@endif<br>@endif{{ $item['description'] ?? '-' }}@if(empty($item['service_name']) && !empty($item['passenger_type'])) <span style="font-size: 8px; color: #888;">· {{ $item['passenger_type'] }}</span>@endif</td>
                <td style="text-align: center; padding: 5px 6px; font-size: 10px; border: 1px solid #ccc;">{{ $item['hsn'] ?? '-' }}</td>
                <td style="text-align: center; padding: 5px 6px; font-size: 10px; border: 1px solid #ccc;">{{ strtoupper($item['unit'] ?? '-') }}</td>
                @if($hasDimensions)
                <td style="text-align: right; padding: 5px 6px; font-size: 10px; border: 1px solid #ccc;">{{ $formatDimension($item['height'] ?? null) }}</td>
                <td style="text-align: right; padding: 5px 6px; font-size: 10px; border: 1px solid #ccc;">{{ $formatDimension($item['width'] ?? null) }}</td>
                <td style="text-align: right; padding: 5px 6px; font-size: 10px; border: 1px solid #ccc;">{{ $formatDimension($item['total'] ?? null) }}</td>
                @endif
                <td style="text-align: right; padding: 5px 6px; font-size: 10px; border: 1px solid #ccc;">{{ number_format($item['qty'] ?? 0, 0) }}</td>
                <td style="text-align: right; padding: 5px 6px; font-size: 10px; border: 1px solid #ccc;">{{ number_format($item['rate'] ?? 0, 0) }}</td>
                <td style="text-align: right; padding: 5px 6px; font-size: 10px; border: 1px solid #ccc;">{{ number_format($itemAmount, 0) }}</td>
                @if($hasLineTax)
                @php $rowTaxType = $item['tax_type'] ?? 'none'; $rowTaxRate = (float) ($item['tax_rate'] ?? 0); @endphp
                <td style="text-align: right; padding: 5px 6px; font-size: 10px; border: 1px solid #ccc;">@if($rowTaxType !== 'none' && $rowTaxRate > 0){{ strtoupper($rowTaxType) }} {{ rtrim(rtrim(number_format($rowTaxRate, 2), '0'), '.') }}%@else-@endif</td>
                @endif
            </tr>
            @endforeach
        </tbody>
    </table>
    @elseif($invoice->invoice_type == 'pdf')
    <div class="pdf-info">
        <div class="pdf-info-title">PDF Invoice Uploaded</div>
        @if($invoice->pdf_description)
        <div class="pdf-info-text">{{ $invoice->pdf_description }}</div>
        @endif
    </div>
    @endif

    
    <div class="summary-row clearfix">
        <div class="notes-section">
            @if($invoice->notes)
            <div class="notes-title">Notes:</div>
            <div class="notes-text">{{ $invoice->notes }}</div>
            @endif
            @if($invoice->terms)
            <div class="notes-title" style="margin-top: 6px;">Terms & Conditions:</div>
            <div class="notes-text">{!! nl2br(e($invoice->terms)) !!}</div>
            @endif
            @if($invoice->payment_terms)
            <div class="notes-title" style="margin-top: 6px;">Payment Terms:</div>
            <div class="notes-text">{!! nl2br(e($invoice->payment_terms)) !!}</div>
            @endif
        </div>
        <div class="totals-section">
            <table style="width: 100%; border-collapse: collapse;">
                <tr>
                    <td style="padding: 4px 6px; font-size: 11px; border-bottom: 1px solid #eee; text-align: right; color: #666; width: 60%;">Subtotal:</td>
                    <td style="padding: 4px 6px; font-size: 11px; border-bottom: 1px solid #eee; text-align: right; font-weight: bold; color: #333;">{{ $currencySymbol }} {{ number_format($invoice->subtotal, 0) }}</td>
                </tr>
                @if($invoice->discount > 0)
                <tr>
                    <td style="padding: 4px 6px; font-size: 11px; border-bottom: 1px solid #eee; text-align: right; color: #666; width: 60%;">Discount:</td>
                    <td style="padding: 4px 6px; font-size: 11px; border-bottom: 1px solid #eee; text-align: right; font-weight: bold; color: #e74c3c;">- {{ $currencySymbol }} {{ number_format($invoice->discount, 0) }}</td>
                </tr>
                @endif
                @php $hasLineTax = $hasLineTax ?? false; $lineTaxByType = $lineTaxByType ?? ['gst' => 0, 'vat' => 0]; @endphp
                @if($hasLineTax)
                    @if($lineTaxByType['gst'] > 0)
                        @if($invoice->gst_split)
                        <tr>
                            <td style="padding: 4px 6px; font-size: 11px; border-bottom: 1px solid #eee; text-align: right; color: #666; width: 60%;">CGST{{ $invoice->gst_inclusive ? ' - Inclusive' : '' }}:</td>
                            <td style="padding: 4px 6px; font-size: 11px; border-bottom: 1px solid #eee; text-align: right; font-weight: bold; color: {{ $invoice->gst_inclusive ? '#333' : '#27ae60' }};">{{ $invoice->gst_inclusive ? '' : '+ ' }}{{ $currencySymbol }} {{ number_format($lineTaxByType['gst'] / 2, 0) }}</td>
                        </tr>
                        <tr>
                            <td style="padding: 4px 6px; font-size: 11px; border-bottom: 1px solid #eee; text-align: right; color: #666; width: 60%;">SGST{{ $invoice->gst_inclusive ? ' - Inclusive' : '' }}:</td>
                            <td style="padding: 4px 6px; font-size: 11px; border-bottom: 1px solid #eee; text-align: right; font-weight: bold; color: {{ $invoice->gst_inclusive ? '#333' : '#27ae60' }};">{{ $invoice->gst_inclusive ? '' : '+ ' }}{{ $currencySymbol }} {{ number_format($lineTaxByType['gst'] / 2, 0) }}</td>
                        </tr>
                        @else
                        <tr>
                            <td style="padding: 4px 6px; font-size: 11px; border-bottom: 1px solid #eee; text-align: right; color: #666; width: 60%;">GST{{ $invoice->gst_inclusive ? ' - Inclusive' : '' }}:</td>
                            <td style="padding: 4px 6px; font-size: 11px; border-bottom: 1px solid #eee; text-align: right; font-weight: bold; color: {{ $invoice->gst_inclusive ? '#333' : '#27ae60' }};">{{ $invoice->gst_inclusive ? '' : '+ ' }}{{ $currencySymbol }} {{ number_format($lineTaxByType['gst'], 0) }}</td>
                        </tr>
                        @endif
                    @endif
                    @if($lineTaxByType['vat'] > 0)
                    <tr>
                        <td style="padding: 4px 6px; font-size: 11px; border-bottom: 1px solid #eee; text-align: right; color: #666; width: 60%;">VAT:</td>
                        <td style="padding: 4px 6px; font-size: 11px; border-bottom: 1px solid #eee; text-align: right; font-weight: bold; color: #27ae60;">+ {{ $currencySymbol }} {{ number_format($lineTaxByType['vat'], 0) }}</td>
                    </tr>
                    @endif
                @elseif($invoice->gst_percent > 0)
                    @if($invoice->gst_split)
                    <tr>
                        <td style="padding: 4px 6px; font-size: 11px; border-bottom: 1px solid #eee; text-align: right; color: #666; width: 60%;">CGST ({{ $invoice->gst_percent / 2 }}%){{ $invoice->gst_inclusive ? ' - Inclusive' : '' }}:</td>
                        <td style="padding: 4px 6px; font-size: 11px; border-bottom: 1px solid #eee; text-align: right; font-weight: bold; color: {{ $invoice->gst_inclusive ? '#333' : '#27ae60' }};">{{ $invoice->gst_inclusive ? '' : '+ ' }}{{ $currencySymbol }} {{ number_format($invoice->gst / 2, 0) }}</td>
                    </tr>
                    <tr>
                        <td style="padding: 4px 6px; font-size: 11px; border-bottom: 1px solid #eee; text-align: right; color: #666; width: 60%;">SGST ({{ $invoice->gst_percent / 2 }}%){{ $invoice->gst_inclusive ? ' - Inclusive' : '' }}:</td>
                        <td style="padding: 4px 6px; font-size: 11px; border-bottom: 1px solid #eee; text-align: right; font-weight: bold; color: {{ $invoice->gst_inclusive ? '#333' : '#27ae60' }};">{{ $invoice->gst_inclusive ? '' : '+ ' }}{{ $currencySymbol }} {{ number_format($invoice->gst / 2, 0) }}</td>
                    </tr>
                    @else
                    <tr>
                        <td style="padding: 4px 6px; font-size: 11px; border-bottom: 1px solid #eee; text-align: right; color: #666; width: 60%;">GST ({{ $invoice->gst_percent }}%){{ $invoice->gst_inclusive ? ' - Inclusive' : '' }}:</td>
                        <td style="padding: 4px 6px; font-size: 11px; border-bottom: 1px solid #eee; text-align: right; font-weight: bold; color: {{ $invoice->gst_inclusive ? '#333' : '#27ae60' }};">{{ $invoice->gst_inclusive ? '' : '+ ' }}{{ $currencySymbol }} {{ number_format($invoice->gst, 0) }}</td>
                    </tr>
                    @endif
                @endif
                <tr style="background-color: #f0f4f8;">
                    <td style="padding: 6px; font-size: 12px; text-align: right; font-weight: bold; color: #333;">Grand Total:</td>
                    <td style="padding: 6px; font-size: 13px; text-align: right; font-weight: bold; color: #333; white-space: nowrap;">{{ $currencySymbol }}{{ number_format($invoice->grand_total, 0) }}</td>
                </tr>
            </table>
        </div>
    </div>

    
    @if($invoice->amount_paid > 0 || $invoice->balance_due > 0)
    <div style="margin-top: 12px; padding: 6px; background-color: #f8f9fa; border: 1px solid #ddd;">
        <table style="width: 100%;">
            <tr>
                <td style="width: 33%; text-align: center;">
                    <div style="font-size: 9px; color: #666;">Amount Paid</div>
                    <div style="font-size: 12px; font-weight: bold; color: #27ae60;">{{ $currencySymbol }} {{ number_format($invoice->amount_paid, 0) }}</div>
                </td>
                <td style="width: 33%; text-align: center;">
                    <div style="font-size: 9px; color: #666;">Balance Due</div>
                    <div style="font-size: 12px; font-weight: bold; color: {{ $invoice->balance_due > 0 ? '#e74c3c' : '#27ae60' }};">{{ $currencySymbol }} {{ number_format($invoice->balance_due, 0) }}</div>
                </td>
                <td style="width: 33%; text-align: center;">
                    <div style="font-size: 9px; color: #666;">Status</div>
                    <div style="font-size: 11px; font-weight: bold; color: #333;">{{ strtoupper($invoice->status) }}</div>
                </td>
            </tr>
        </table>
    </div>
    @endif

    
    <div class="footer">
        <div class="signature-box">
            <div class="signature-company">For {{ $invoice->company->name ?? '' }}</div>
            <div class="signature-text">Authorized Signatory</div>
        </div>
    </div>
</body>
</html>
